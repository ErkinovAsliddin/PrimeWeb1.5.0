import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { spawn, ChildProcess } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

// These are integration tests: they boot the real server as a subprocess
// against a throwaway SQLite database and hit it over HTTP, the same way a
// real client would. This is what actually proves auth/validation/rate
// limiting work end-to-end, not just that individual functions compile.

const PORT = 4123;
const BASE_URL = `http://localhost:${PORT}`;
let serverProcess: ChildProcess;
let tempDataDir: string;

function waitForHealth(retries = 40): Promise<void> {
  return new Promise((resolve, reject) => {
    const attempt = (n: number) => {
      fetch(`${BASE_URL}/api/health`)
        .then(res => (res.ok ? resolve() : retry(n)))
        .catch(() => retry(n));
    };
    const retry = (n: number) => {
      if (n <= 0) return reject(new Error('Server did not become healthy in time'));
      setTimeout(() => attempt(n - 1), 250);
    };
    attempt(retries);
  });
}

beforeAll(async () => {
  tempDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'restaurant-test-'));
  serverProcess = spawn('npx', ['tsx', 'server.ts'], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      NODE_ENV: 'test',
      PORT: String(PORT),
      DATABASE_DIR: tempDataDir,
      JWT_SECRET: 'test-secret-at-least-16-chars',
      ADMIN_INITIAL_PASSWORD: 'test-admin-pass',
      KITCHEN_INITIAL_PIN: '9999',
      ALLOWED_ORIGINS: ''
    },
    stdio: 'pipe'
  });
  await waitForHealth();
}, 30_000);

afterAll(() => {
  serverProcess?.kill();
  if (tempDataDir) fs.rmSync(tempDataDir, { recursive: true, force: true });
});

describe('health', () => {
  it('responds ok', async () => {
    const res = await fetch(`${BASE_URL}/api/health`);
    expect(res.status).toBe(200);
  });
});

describe('authorization', () => {
  it('rejects menu writes with no session', async () => {
    const res = await fetch(`${BASE_URL}/api/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Hack Item', price: 1, category: 'mains' })
    });
    expect(res.status).toBe(401);
  });

  it('rejects wrong admin password', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'wrong-password' })
    });
    expect(res.status).toBe(401);
  });

  it('allows menu writes after correct admin login, using the session cookie', async () => {
    const loginRes = await fetch(`${BASE_URL}/api/auth/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'test-admin-pass' })
    });
    expect(loginRes.status).toBe(200);
    const cookie = loginRes.headers.get('set-cookie');
    expect(cookie).toBeTruthy();

    const createRes = await fetch(`${BASE_URL}/api/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie! },
      body: JSON.stringify({ name: 'Real Admin Item', price: 12, category: 'mains', stock: 10 })
    });
    expect(createRes.status).toBe(201);
    const created = await createRes.json();
    expect(created.name).toBe('Real Admin Item');
  });

  it('customers cannot read the full order list (admin/kitchen only)', async () => {
    const res = await fetch(`${BASE_URL}/api/orders`);
    expect(res.status).toBe(401);
  });
});

describe('input validation', () => {
  it('rejects a menu item with a negative price', async () => {
    const loginRes = await fetch(`${BASE_URL}/api/auth/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'test-admin-pass' })
    });
    const cookie = loginRes.headers.get('set-cookie')!;

    const res = await fetch(`${BASE_URL}/api/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ name: 'Bad Item', price: -5, category: 'mains' })
    });
    expect(res.status).toBe(400);
  });

  it('rejects an order referencing a menu item that does not exist', async () => {
    const res = await fetch(`${BASE_URL}/api/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tableNumber: 1,
        items: [
          {
            cartItemId: 'c1',
            menuItem: { id: 'does-not-exist' },
            quantity: 1,
            selectedCustomizations: [],
            itemTotal: 5
          }
        ],
        subtotal: 5,
        tax: 0,
        serviceCharge: 0,
        totalAmount: 5
      })
    });
    expect(res.status).toBe(400);
  });
});

describe('idempotent order creation', () => {
  it('returns the same order for a repeated Idempotency-Key instead of creating a duplicate', async () => {
    const menu = await fetch(`${BASE_URL}/api/menu`).then(r => r.json());
    const item = menu[0];
    const payload = JSON.stringify({
      tableNumber: 7,
      items: [
        {
          cartItemId: 'c1',
          menuItem: { id: item.id },
          quantity: 1,
          selectedCustomizations: [],
          itemTotal: item.price
        }
      ],
      subtotal: item.price,
      tax: 0,
      serviceCharge: 0,
      totalAmount: item.price
    });

    const first = await fetch(`${BASE_URL}/api/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Idempotency-Key': 'dup-test-key' },
      body: payload
    }).then(r => r.json());

    const second = await fetch(`${BASE_URL}/api/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Idempotency-Key': 'dup-test-key' },
      body: payload
    }).then(r => r.json());

    expect(second.id).toBe(first.id);
  });
});

describe('rate limiting', () => {
  it('locks out repeated failed admin logins', async () => {
    const attempts = await Promise.all(
      Array.from({ length: 12 }).map(() =>
        fetch(`${BASE_URL}/api/auth/kitchen/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password: 'wrong' })
        })
      )
    );
    const statusCodes = attempts.map(r => r.status);
    // Either the per-minute rate limiter (429) or the DB-backed lockout (429)
    // should kick in well before 12 attempts succeed through as plain 401s.
    expect(statusCodes.some(code => code === 429)).toBe(true);
  });
});

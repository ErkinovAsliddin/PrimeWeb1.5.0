import { MenuItem, Table, LoyaltyMember, Order } from '../types';

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  {
    id: 'm1',
    name: 'Truffle & Parmesan Gourmet Fries',
    nameUz: "Truffel va Parmezan Kartoshka Fri",
    nameRu: "Картофель Фри с Трюфелем и Пармезаном",
    nameEn: 'Truffle & Parmesan Gourmet Fries',
    description: 'Crispy hand-cut fries tossed in real black truffle oil, freshly grated Aged Parmesan, garlic aioli, and sea salt.',
    descriptionUz: "Qora truffel yog'ida qovurilgan qarsillama kartoshka fri, yangi qirilgan Parmezan pishlog'i, sarimsoqli sous va dengiz tuzi bilan.",
    descriptionRu: "Хрустящий картофель фри в настоящем черном трюфельном масле с тертым пармезаном, чесночным айоли и морской солью.",
    descriptionEn: 'Crispy hand-cut fries tossed in real black truffle oil, freshly grated Aged Parmesan, garlic aioli, and sea salt.',
    price: 114000,
    category: 'garnir',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=800&q=80',
    stock: 24,
    isAvailable: true,
    dietary: ['vegetarian', 'chef-recommendation'],
    prepTimeMinutes: 10,
    calories: 480,
    customizations: [
      {
        id: 'dip',
        title: 'Choose Dipping Sauce',
        required: false,
        options: [
          { id: 'd1', name: 'Garlic Aioli', price: 0 },
          { id: 'd2', name: 'Spicy Sriracha Mayo', price: 9000 },
          { id: 'd3', name: 'Truffle Ketchup', price: 12000 }
        ]
      }
    ]
  },
  {
    id: 'm2',
    name: 'Crispy Calamari Fritti',
    nameUz: "Qarsillama Kalmar Fritti",
    nameRu: "Хрустящие Кольца Кальмара",
    nameEn: 'Crispy Calamari Fritti',
    description: 'Wild-caught squid rings fried to golden perfection with zesty lemon pepper, char-grilled lemon wheel, and house marinara.',
    descriptionUz: "Yangi ushlangan kalmar halqalari limon-murch bilan qarsillab qovurilgan, limon bo'lagi va uy sousi bilan.",
    descriptionRu: "Свежие кольца кальмара, обжаренные до золотистой корочки с лимонным перцем, долькой лимона и домашним соусом маринара.",
    descriptionEn: 'Wild-caught squid rings fried to golden perfection with zesty lemon pepper, char-grilled lemon wheel, and house marinara.',
    price: 156000,
    category: 'garnir',
    image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80',
    stock: 18,
    isAvailable: true,
    dietary: ['chef-recommendation'],
    prepTimeMinutes: 12,
    calories: 520,
    customizations: [
      {
        id: 'dip-calamari',
        title: 'Extra Dip',
        required: false,
        options: [
          { id: 'c1', name: 'House Marinara', price: 0 },
          { id: 'c2', name: 'Smoked Jalapeño Mayo', price: 10000 }
        ]
      }
    ]
  },
  {
    id: 'm3',
    name: 'Artisan Burrata & Heirloom Tomato',
    nameUz: "Burrata Pishlog'i va Pomidor Salatasi",
    nameRu: "Буррата с Томатами",
    nameEn: 'Artisan Burrata & Heirloom Tomato',
    description: 'Creamy Pugliese burrata cheese, organic heirloom tomatoes, basil pesto glaze, toasted pine nuts, and grilled sourdough.',
    descriptionUz: "Yumshoq Pugliya burrata pishlog'i, organik pomidorlar, bazilika pesto, qovurilgan qarag'ay yong'og'i va tosh non bilan.",
    descriptionRu: "Нежный сыр буррата, органические томаты, соус песто с базиликом, кедровые орешки и поджаренный хлеб.",
    descriptionEn: 'Creamy Pugliese burrata cheese, organic heirloom tomatoes, basil pesto glaze, toasted pine nuts, and grilled sourdough.',
    price: 174000,
    category: 'garnir',
    image: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb231fc?auto=format&fit=crop&w=800&q=80',
    stock: 12,
    isAvailable: true,
    dietary: ['vegetarian'],
    prepTimeMinutes: 8,
    calories: 410
  },
  {
    id: 'm4',
    name: 'Prime Wagyu Smash Burger',
    nameUz: "Wagyu Gushtli Burger",
    nameRu: "Бургер с Вагю",
    nameEn: 'Prime Wagyu Smash Burger',
    description: 'Double 100% Wagyu beef patties, melted aged cheddar, caramelized onion jam, pickles, and signature house burger sauce on toasted brioche.',
    descriptionUz: "Ikkita 100% Wagyu mol go'shti kotleti, eritilgan cheddar pishloq, karamellangan piyoz, tuzlangan bodring va maxsus sous bilan brioche nonda.",
    descriptionRu: "Двойные котлеты из говядины вагю, плавленый сыр чеддер, карамелизированный лук, соленые огурцы и фирменный соус на булочке бриошь.",
    descriptionEn: 'Double 100% Wagyu beef patties, melted aged cheddar, caramelized onion jam, pickles, and signature house burger sauce on toasted brioche.',
    price: 222000,
    category: 'ikkinchi_taom',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    stock: 20,
    isAvailable: true,
    dietary: ['chef-recommendation'],
    prepTimeMinutes: 15,
    calories: 890,
    customizations: [
      {
        id: 'bun',
        title: 'Bun Preference',
        required: true,
        options: [
          { id: 'b1', name: 'Brioche Bun', price: 0 },
          { id: 'b2', name: 'Gluten-Free Bun', price: 18000 },
          { id: 'b3', name: 'Lettuce Wrap (Low Carb)', price: 0 }
        ]
      },
      {
        id: 'addons',
        title: 'Add Extra Toppings',
        required: false,
        options: [
          { id: 'a1', name: 'Crispy Smoked Bacon', price: 30000 },
          { id: 'a2', name: 'Fried Farm Egg', price: 18000 },
          { id: 'a3', name: 'Extra Wagyu Patty', price: 60000 },
          { id: 'a4', name: 'Avocado Slices', price: 24000 }
        ]
      }
    ]
  },
  {
    id: 'm5',
    name: 'Wood-Fired Margherita Pizza',
    nameUz: "O'tinda Pishirilgan Margarita Pitsasi",
    nameRu: "Пицца Маргарита на Дровах",
    nameEn: 'Wood-Fired Margherita Pizza',
    description: 'San Marzano tomato sauce, fresh buffalo mozzarella, aromatic sweet basil leaves, and cold-pressed extra virgin olive oil.',
    descriptionUz: "San Marzano pomidor sousi, yangi mozzarella pishlog'i, rayhon barglari va zaytun yog'i bilan.",
    descriptionRu: "Томатный соус Сан-Марцано, свежая моцарелла, свежий базилик и оливковое масло холодного отжима.",
    descriptionEn: 'San Marzano tomato sauce, fresh buffalo mozzarella, aromatic sweet basil leaves, and cold-pressed extra virgin olive oil.',
    price: 192000,
    category: 'ikkinchi_taom',
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=800&q=80',
    stock: 15,
    isAvailable: true,
    dietary: ['vegetarian'],
    prepTimeMinutes: 14,
    calories: 780,
    customizations: [
      {
        id: 'crust',
        title: 'Crust Style',
        required: true,
        options: [
          { id: 'cr1', name: 'Neapolitan Soft Crust', price: 0 },
          { id: 'cr2', name: 'Crispy Thin Crust', price: 0 },
          { id: 'cr3', name: 'Gluten-Free Base', price: 36000 }
        ]
      }
    ]
  },
  {
    id: 'm6',
    name: 'Pan-Seared Atlantic Salmon',
    nameUz: "Tovada Qovurilgan Losos Baliq",
    nameRu: "Лосось на Сковороде",
    nameEn: 'Pan-Seared Atlantic Salmon',
    description: 'Crispy skin salmon fillet served over saffron risotto, asparagus spears, and garlic herb butter cream.',
    descriptionUz: "Qarsillama terili losos filesi za'faron risotto, qulupnay va sarimsoqli yog' sousi bilan.",
    descriptionRu: "Лосось с хрустящей кожей на шафрановом ризотто со спаржей и чесночно-сливочным соусом.",
    descriptionEn: 'Crispy skin salmon fillet served over saffron risotto, asparagus spears, and garlic herb butter cream.',
    price: 288000,
    category: 'ikkinchi_taom',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80',
    stock: 8,
    isAvailable: true,
    dietary: ['gluten-free', 'chef-recommendation'],
    prepTimeMinutes: 18,
    calories: 640
  },
  {
    id: 'm7',
    name: 'Spicy Thai Basil Noodle (Pad Krapow)',
    nameUz: "Achchiq Tay Bazilikali Lag'mon (Pad Krapow)",
    nameRu: "Острая Тайская Лапша с Базиликом",
    nameEn: 'Spicy Thai Basil Noodle (Pad Krapow)',
    description: 'Stir-fried rice noodles, minced chicken or tofu, Thai bird chillies, garlic, sweet dark soy sauce, and crispy holy basil.',
    descriptionUz: "Qovurilgan guruch lag'moni, mayda to'g'ralgan tovuq yoki tofu, tay achchiq murchi, sarimsoq va bazilika bilan.",
    descriptionRu: "Жареная рисовая лапша с курицей или тофу, тайским острым перцем, чесноком и свежим базиликом.",
    descriptionEn: 'Stir-fried rice noodles, minced chicken or tofu, Thai bird chillies, garlic, sweet dark soy sauce, and crispy holy basil.',
    price: 186000,
    category: 'ikkinchi_taom',
    image: 'https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=800&q=80',
    stock: 14,
    isAvailable: true,
    dietary: ['spicy', 'halal'],
    prepTimeMinutes: 12,
    calories: 590,
    customizations: [
      {
        id: 'protein',
        title: 'Select Protein',
        required: true,
        options: [
          { id: 'p1', name: 'Chicken Breast', price: 0 },
          { id: 'p2', name: 'Organic Tofu & Mushrooms', price: 0 },
          { id: 'p3', name: 'Tiger Prawns', price: 42000 }
        ]
      },
      {
        id: 'spice',
        title: 'Spice Level',
        required: true,
        options: [
          { id: 's1', name: 'Mild (1 Chilli)', price: 0 },
          { id: 's2', name: 'Medium Thai (2 Chillies)', price: 0 },
          { id: 's3', name: 'Hot Authentic (3 Chillies 🔥)', price: 0 }
        ]
      }
    ]
  },
  {
    id: 'm8',
    name: 'Chef’s Slow-Braised Short Ribs',
    nameUz: "Sekin Pishirilgan Qovurg'a",
    nameRu: "Томленые Ребрышки",
    nameEn: 'Chef’s Slow-Braised Short Ribs',
    description: '12-hour braised beef short rib in rich red wine reduction, smooth potato mousseline, roasted baby carrots, and crispy shallots.',
    descriptionUz: "12 soat davomida qizil vino sousida pishirilgan mol qovurg'asi, kartoshka pyuresi va qovurilgan sabzi bilan.",
    descriptionRu: "Говяжьи ребра, томленные 12 часов в соусе из красного вина, с картофельным пюре и жареной морковью.",
    descriptionEn: '12-hour braised beef short rib in rich red wine reduction, smooth potato mousseline, roasted baby carrots, and crispy shallots.',
    price: 342000,
    category: 'ikkinchi_taom',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    stock: 6,
    isAvailable: true,
    dietary: ['chef-recommendation'],
    prepTimeMinutes: 20,
    calories: 920
  },
  {
    id: 'm9',
    name: 'Iced Yuzu & Wild Dragonfruit Sparkler',
    nameUz: "Muzli Yuzu va Ajdaho Mevali Ichimlik",
    nameRu: "Юдзу и Драконий Фрукт со Льдом",
    nameEn: 'Iced Yuzu & Wild Dragonfruit Sparkler',
    description: 'Refreshing Japanese Yuzu citrus juice infused with fresh pink dragonfruit, sparkling soda, and mint leaves.',
    descriptionUz: "Yaponiya yuzu sitrusi sharbati, ajdaho mevasi, gazlangan soda va yalpiz barglari bilan tetiklantiruvchi ichimlik.",
    descriptionRu: "Освежающий напиток с соком японского юдзу, драконьим фруктом, газированной содой и мятой.",
    descriptionEn: 'Refreshing Japanese Yuzu citrus juice infused with fresh pink dragonfruit, sparkling soda, and mint leaves.',
    price: 78000,
    category: 'ichimlik',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80',
    stock: 40,
    isAvailable: true,
    dietary: ['vegan', 'gluten-free'],
    prepTimeMinutes: 4,
    calories: 120,
    customizations: [
      {
        id: 'sweetness',
        title: 'Sweetness Level',
        required: false,
        options: [
          { id: 'sw1', name: 'Regular (100%)', price: 0 },
          { id: 'sw2', name: 'Less Sweet (50%)', price: 0 },
          { id: 'sw3', name: 'Zero Sugar', price: 0 }
        ]
      }
    ]
  },
  {
    id: 'm10',
    name: 'Artisanal Cold Brew Coffee',
    nameUz: "Sovuq Damlangan Qahva",
    nameRu: "Холодный Кофе",
    nameEn: 'Artisanal Cold Brew Coffee',
    description: 'Steeped for 18 hours using single-origin Ethiopian beans. Smooth floral notes with subtle dark chocolate finish.',
    descriptionUz: "18 soat davomida Efiopiya donalaridan damlangan, yumshoq gulli va shokoladli ta'mga ega qahva.",
    descriptionRu: "Кофе, настоянный 18 часов на эфиопских зернах одного происхождения. Мягкий цветочный вкус с оттенком темного шоколада.",
    descriptionEn: 'Steeped for 18 hours using single-origin Ethiopian beans. Smooth floral notes with subtle dark chocolate finish.',
    price: 66000,
    category: 'ichimlik',
    image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=800&q=80',
    stock: 35,
    isAvailable: true,
    dietary: ['vegan', 'gluten-free'],
    prepTimeMinutes: 3,
    calories: 15,
    customizations: [
      {
        id: 'milk',
        title: 'Milk Choice',
        required: false,
        options: [
          { id: 'm1', name: 'Whole Milk', price: 0 },
          { id: 'm2', name: 'Oat Milk', price: 10000 },
          { id: 'm3', name: 'Almond Milk', price: 10000 }
        ]
      }
    ]
  },
  {
    id: 'm11',
    name: 'Signature Passionfruit Matcha Latte',
    nameUz: "Marakuya bilan Matcha Latte",
    nameRu: "Матча Латте с Маракуйей",
    nameEn: 'Signature Passionfruit Matcha Latte',
    description: 'Ceremonial grade Uji green tea matcha layered over fresh passionfruit puree and velvety oat milk.',
    descriptionUz: "Yaponiya matcha choyi, yangi marakuya pyuresi va yumshoq suli sutida.",
    descriptionRu: "Церемониальная матча, свежее пюре маракуйи и нежное овсяное молоко.",
    descriptionEn: 'Ceremonial grade Uji green tea matcha layered over fresh passionfruit puree and velvety oat milk.',
    price: 84000,
    category: 'ichimlik',
    image: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=800&q=80',
    stock: 25,
    isAvailable: true,
    dietary: ['vegetarian', 'chef-recommendation'],
    prepTimeMinutes: 5,
    calories: 190
  },
  {
    id: 'm12',
    name: 'Molten Belgian Chocolate Lava Cake',
    nameUz: "Belgiya Shokoladli Lava Keksi",
    nameRu: "Бельгийский Шоколадный Кекс",
    nameEn: 'Molten Belgian Chocolate Lava Cake',
    description: 'Warm chocolate cake with oozing Belgian dark chocolate core, served with Madagascar vanilla bean gelato and fresh berries.',
    descriptionUz: "Ichi suyuq Belgiya shokoladli issiq keks, vanil muzqaymog'i va yangi rezavorlar bilan.",
    descriptionRu: "Теплый шоколадный кекс с жидкой начинкой из бельгийского темного шоколада, ванильным мороженым и свежими ягодами.",
    descriptionEn: 'Warm chocolate cake with oozing Belgian dark chocolate core, served with Madagascar vanilla bean gelato and fresh berries.',
    price: 132000,
    category: 'nonushta',
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80',
    stock: 10,
    isAvailable: true,
    dietary: ['vegetarian', 'chef-recommendation'],
    prepTimeMinutes: 12,
    calories: 620
  },
  {
    id: 'm13',
    name: 'Classic Venetian Tiramisu',
    nameUz: "Klassik Venetsiya Tiramisu",
    nameRu: "Классический Тирамису",
    nameEn: 'Classic Venetian Tiramisu',
    description: 'Layers of espresso-soaked savoiardi ladyfingers, rich mascarpone cream, dark rum essence, and dusted Valrhona cocoa powder.',
    descriptionUz: "Espresso kofesiga botirilgan savoyardi pechenyesi, maskarpone kremi va kakao kukuni bilan.",
    descriptionRu: "Печенье савоярди, пропитанное эспрессо, со сливочным кремом маскарпоне и какао-порошком.",
    descriptionEn: 'Layers of espresso-soaked savoiardi ladyfingers, rich mascarpone cream, dark rum essence, and dusted Valrhona cocoa powder.',
    price: 114000,
    category: 'nonushta',
    image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=80',
    stock: 14,
    isAvailable: true,
    dietary: ['vegetarian'],
    prepTimeMinutes: 5,
    calories: 450
  }
];

export const INITIAL_TABLES: Table[] = Array.from({ length: 12 }, (_, i) => ({
  tableNumber: i + 1,
  capacity: i % 2 === 0 ? 4 : 2,
  status: i === 2 ? 'ordering' : i === 4 ? 'eating' : i === 7 ? 'seated' : 'available',
  currentOrderId: i === 4 ? 'ORD-104' : undefined,
  activeItemsCount: i === 4 ? 3 : 0
}));

export const INITIAL_LOYALTY_MEMBERS: LoyaltyMember[] = [
  {
    id: 'loy-1',
    name: 'Jane Doe',
    phoneOrEmail: 'jane.doe@example.com',
    confirmationCode: '1234',
    pointsBalance: 450,
    tier: 'Gold',
    totalSpent: 4140000,
    ordersCount: 8,
    joinedDate: '2026-01-15'
  },
  {
    id: 'loy-2',
    name: 'Sarah Connor',
    phoneOrEmail: '555-0192',
    confirmationCode: '5678',
    pointsBalance: 120,
    tier: 'Silver',
    totalSpent: 1182000,
    ordersCount: 3,
    joinedDate: '2026-03-20'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-104',
    tableNumber: 5,
    customerName: 'Sarah Connor',
    customerPhoneOrEmail: '555-0192',
    items: [
      {
        cartItemId: 'c-101',
        menuItem: INITIAL_MENU_ITEMS[3], // Wagyu Burger
        quantity: 2,
        selectedCustomizations: [{ groupTitle: 'Bun Preference', optionName: 'Brioche Bun', price: 0 }],
        specialInstructions: 'Medium rare meat, extra napkins please',
        itemTotal: 444000
      },
      {
        cartItemId: 'c-102',
        menuItem: INITIAL_MENU_ITEMS[8], // Yuzu Sparkler
        quantity: 2,
        selectedCustomizations: [{ groupTitle: 'Sweetness Level', optionName: 'Less Sweet (50%)', price: 0 }],
        itemTotal: 156000
      }
    ],
    subtotal: 600000,
    tax: 48000,
    serviceCharge: 30000,
    discount: 0,
    totalAmount: 678000,
    status: 'preparing',
    paymentStatus: 'unpaid',
    createdAt: new Date(Date.now() - 12 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 60000).toISOString(),
    estimatedMinutes: 15,
    loyaltyPointsEarned: 565,
    loyaltyPointsRedeemed: 0
  },
  {
    id: 'ORD-103',
    tableNumber: 2,
    customerName: 'Guest Table 2',
    customerPhoneOrEmail: 'table2@dine.in',
    items: [
      {
        cartItemId: 'c-103',
        menuItem: INITIAL_MENU_ITEMS[0], // Truffle Fries
        quantity: 1,
        selectedCustomizations: [{ groupTitle: 'Choose Dipping Sauce', optionName: 'Garlic Aioli', price: 0 }],
        itemTotal: 114000
      },
      {
        cartItemId: 'c-104',
        menuItem: INITIAL_MENU_ITEMS[4], // Margherita Pizza
        quantity: 1,
        selectedCustomizations: [{ groupTitle: 'Crust Style', optionName: 'Neapolitan Soft Crust', price: 0 }],
        itemTotal: 192000
      }
    ],
    subtotal: 306000,
    tax: 24000,
    serviceCharge: 15000,
    discount: 0,
    totalAmount: 346000,
    status: 'ready',
    paymentStatus: 'unpaid',
    createdAt: new Date(Date.now() - 22 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 60000).toISOString(),
    estimatedMinutes: 14,
    loyaltyPointsEarned: 288,
    loyaltyPointsRedeemed: 0
  }
];

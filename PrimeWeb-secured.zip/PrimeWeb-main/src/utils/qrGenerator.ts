import QRCode from 'qrcode';

/**
 * Generates a real, standard, 100% camera-scannable QR code Data URL for a table.
 */
export async function generateTableQRDataUrlAsync(tableNumber: number, appUrl: string): Promise<string> {
  const fullUrl = `${appUrl.replace(/\/$/, '')}?table=${tableNumber}`;
  try {
    return await QRCode.toDataURL(fullUrl, {
      width: 400,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M'
    });
  } catch (e) {
    console.error('Error generating QR code:', e);
    return '';
  }
}

/**
 * Synchronous helper fallback returning full URL encoded string for quick display
 */
export function getTableFullUrl(tableNumber: number, appUrl: string): string {
  return `${appUrl.replace(/\/$/, '')}?table=${tableNumber}`;
}

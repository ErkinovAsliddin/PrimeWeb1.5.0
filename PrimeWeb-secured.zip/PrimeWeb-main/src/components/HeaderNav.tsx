import React, { useState } from 'react';
import { AppViewMode, GoogleUser } from '../types';
import { Utensils, ChefHat, LayoutDashboard, QrCode, Smartphone, Lock, MapPin, UserCheck, Menu, X, Phone, Instagram, ShieldCheck, Sparkles } from 'lucide-react';
import { Language, translations } from '../lib/translations';

interface HeaderNavProps {
  currentView: AppViewMode;
  onViewChange: (view: AppViewMode) => void;
  tableNumber: number | null;
  onChangeTableClick: () => void;
  onOpenQRScanner: () => void;
  onOpenLocation: () => void;
  onOpenGoogleAuth: () => void;
  googleUser: GoogleUser | null;
  isRealtimeConnected: boolean;
  cartCount: number;
  onOpenCart: () => void;
  onOpenLoyalty: () => void;
  loyaltyPoints?: number;
  customerName?: string;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  isAdminAuthenticated: boolean;
  isKitchenAuthenticated: boolean;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentView,
  onViewChange,
  tableNumber,
  onChangeTableClick,
  onOpenQRScanner,
  onOpenLocation,
  onOpenGoogleAuth,
  googleUser,
  isRealtimeConnected,
  cartCount,
  onOpenCart,
  onOpenLoyalty,
  loyaltyPoints,
  customerName,
  lang,
  onLanguageChange,
  isAdminAuthenticated,
  isKitchenAuthenticated
}) => {
  const t = translations[lang];
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md text-zinc-900 border-b border-zinc-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16 gap-1.5 sm:gap-2">
            
            {/* Top Left: Hamburger 3-Dashes Menu + Logo */}
            <div className="flex items-center space-x-2 shrink-0">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-zinc-700 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 rounded-xl transition-colors border border-zinc-200/80 shrink-0"
                title="Open Navigation Menu"
                aria-label="Navigation Menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5 text-zinc-900" /> : <Menu className="w-5 h-5 text-zinc-900" />}
              </button>

              <button 
                onClick={() => onViewChange('customer')}
                className="flex items-center space-x-1.5 text-left group"
              >
                <div className="w-7 h-7 sm:w-8 sm:h-8 bg-orange-500 group-hover:bg-orange-600 rounded-lg sm:rounded-xl flex items-center justify-center text-white font-bold shadow-xs transition-colors shrink-0">
                  <Utensils className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                </div>
                <div className="hidden min-[380px]:block">
                  <div className="flex items-center space-x-1">
                    <span className="font-black text-xs sm:text-sm tracking-tight text-zinc-900 uppercase">
                      {t.appTitle}
                    </span>
                    <span className="bg-orange-50 text-orange-800 text-[8px] sm:text-[9px] font-bold px-1 py-0.2 rounded-md border border-orange-200">
                      Bulvar
                    </span>
                  </div>
                </div>
              </button>
            </div>

            {/* Desktop Navigation Tabs (Hidden on small mobile screens) */}
            <div className="hidden md:flex items-center bg-zinc-100/90 p-1 rounded-xl border border-zinc-200/90 shadow-inner shrink-0">
              <button
                onClick={() => onViewChange('customer')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  currentView === 'customer'
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
                title={t.digitalMenu}
              >
                <Smartphone className="w-3.5 h-3.5 shrink-0" />
                <span>{t.digitalMenu}</span>
              </button>

              <button
                onClick={() => onViewChange('kitchen')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  currentView === 'kitchen'
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
                title={t.kitchen}
              >
                {isKitchenAuthenticated ? <ChefHat className="w-3.5 h-3.5 shrink-0" /> : <Lock className="w-3.5 h-3.5 shrink-0 text-amber-500" />}
                <span>{t.kitchen}</span>
              </button>

              <button
                onClick={() => onViewChange('admin')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  currentView === 'admin'
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
                title={t.admin}
              >
                {isAdminAuthenticated ? <LayoutDashboard className="w-3.5 h-3.5 shrink-0" /> : <Lock className="w-3.5 h-3.5 shrink-0 text-amber-500" />}
                <span>{t.admin}</span>
              </button>
            </div>

            {/* Right Action Items */}
            <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
              
              {/* Location & Contact Button */}
              <button
                onClick={onOpenLocation}
                className="bg-orange-50 hover:bg-orange-100 text-orange-900 p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg sm:rounded-xl border border-orange-200 text-xs font-bold flex items-center space-x-1 transition-colors shrink-0"
                title="Prime Restaurant Location & Contact"
              >
                <MapPin className="w-3.5 h-3.5 shrink-0 text-orange-500" />
                <span className="text-[11px] font-extrabold hidden sm:inline">Bulvar</span>
              </button>

              {/* Google OAuth Login Button / Profile Badge */}
              <button
                onClick={onOpenGoogleAuth}
                className={`p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg sm:rounded-xl border text-xs font-extrabold flex items-center space-x-1.5 transition-all shadow-xs shrink-0 ${
                  googleUser
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900 hover:bg-emerald-100'
                    : 'bg-white hover:bg-zinc-50 border-zinc-200 text-zinc-800'
                }`}
                title={googleUser ? `Gmail: ${googleUser.email}` : t.googleSignIn}
              >
                {googleUser ? (
                  <>
                    {googleUser.picture ? (
                      <img src={googleUser.picture} alt="" className="w-4 h-4 rounded-full border border-emerald-400 shrink-0" />
                    ) : (
                      <UserCheck className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                    )}
                    <span className="hidden sm:inline text-[11px] font-bold max-w-[80px] truncate">{googleUser.givenName || googleUser.name}</span>
                  </>
                ) : (
                  <>
                    <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.15C3.26 21.36 7.37 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.15 0 9.99 0 12s.45 3.85 1.24 5.42l4.04-3.15z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.37 0 3.26 2.64 1.24 6.58l4.04 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                      />
                    </svg>
                    <span className="hidden sm:inline text-[11px]">Gmail</span>
                  </>
                )}
              </button>

              {/* Language Switcher Buttons (Desktop) */}
              <div className="hidden sm:flex items-center bg-zinc-100 p-0.5 rounded-lg border border-zinc-200 shrink-0">
                <button
                  onClick={() => onLanguageChange('uz')}
                  className={`px-1.5 py-0.5 text-[10px] font-extrabold rounded-md transition-colors ${
                    lang === 'uz' ? 'bg-orange-500 text-white' : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                  title="O'zbekcha"
                >
                  UZ
                </button>
                <button
                  onClick={() => onLanguageChange('ru')}
                  className={`px-1.5 py-0.5 text-[10px] font-extrabold rounded-md transition-colors ${
                    lang === 'ru' ? 'bg-orange-500 text-white' : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                  title="Русский"
                >
                  RU
                </button>
                <button
                  onClick={() => onLanguageChange('en')}
                  className={`px-1.5 py-0.5 text-[10px] font-extrabold rounded-md transition-colors ${
                    lang === 'en' ? 'bg-orange-500 text-white' : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                  title="English"
                >
                  EN
                </button>
              </div>

              {/* Cart Button */}
              {currentView === 'customer' && (
                <button
                  onClick={onOpenCart}
                  className="relative bg-orange-500 hover:bg-orange-600 text-white font-bold p-1.5 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-xs flex items-center space-x-1 shadow-md shadow-orange-500/20 transition-all transform active:scale-95 shrink-0"
                >
                  <Utensils className="w-3.5 h-3.5 shrink-0" />
                  {cartCount > 0 && (
                    <span className="bg-white text-orange-600 font-black text-[10px] px-1.5 py-0.2 rounded-full">
                      {cartCount}
                    </span>
                  )}
                </button>
              )}

            </div>

          </div>
        </div>
      </header>

      {/* Slide-out Mobile Navigation Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex animate-fadeIn">
          {/* Overlay backdrop */}
          <div
            className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />

          {/* Drawer Sidebar Content */}
          <div className="relative w-full max-w-xs bg-white h-full shadow-2xl flex flex-col justify-between p-5 overflow-y-auto animate-slideRight">
            
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-zinc-100">
                <div className="flex items-center space-x-2.5">
                  <div className="w-9 h-9 bg-orange-500 text-white rounded-2xl flex items-center justify-center font-black text-base shadow-sm">
                    P
                  </div>
                  <div>
                    <h2 className="font-extrabold text-base text-zinc-900 leading-tight uppercase">{t.appTitle}</h2>
                    <p className="text-[11px] text-orange-600 font-bold">Samarkand Branch</p>
                  </div>
                </div>

                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-zinc-400 hover:text-zinc-800 bg-zinc-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Language Switcher Section */}
              <div className="space-y-2">
                <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider block">Language / Tillar</span>
                <div className="grid grid-cols-3 gap-1.5 bg-zinc-100 p-1 rounded-xl border border-zinc-200">
                  <button
                    onClick={() => onLanguageChange('uz')}
                    className={`py-1.5 text-xs font-black rounded-lg transition-all ${
                      lang === 'uz' ? 'bg-orange-500 text-white shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    🇺🇿 O'zbek
                  </button>
                  <button
                    onClick={() => onLanguageChange('ru')}
                    className={`py-1.5 text-xs font-black rounded-lg transition-all ${
                      lang === 'ru' ? 'bg-orange-500 text-white shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    🇷🇺 Русский
                  </button>
                  <button
                    onClick={() => onLanguageChange('en')}
                    className={`py-1.5 text-xs font-black rounded-lg transition-all ${
                      lang === 'en' ? 'bg-orange-500 text-white shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    🇬🇧 English
                  </button>
                </div>
              </div>

              {/* Primary Application Modules */}
              <div className="space-y-2">
                <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider block">Navigation Modules</span>
                
                <button
                  onClick={() => {
                    onViewChange('customer');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border text-xs font-extrabold transition-all ${
                    currentView === 'customer'
                      ? 'bg-orange-50 border-orange-200 text-orange-900 shadow-2xs'
                      : 'bg-zinc-50 border-zinc-200/80 text-zinc-700 hover:bg-zinc-100'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-xl bg-orange-500 text-white">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <span>{t.digitalMenu}</span>
                  </div>
                  {currentView === 'customer' && <span className="text-orange-600 font-bold text-xs">Active</span>}
                </button>

                <button
                  onClick={() => {
                    onViewChange('kitchen');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border text-xs font-extrabold transition-all ${
                    currentView === 'kitchen'
                      ? 'bg-orange-50 border-orange-200 text-orange-900 shadow-2xs'
                      : 'bg-zinc-50 border-zinc-200/80 text-zinc-700 hover:bg-zinc-100'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-xl bg-zinc-800 text-white">
                      {isKitchenAuthenticated ? <ChefHat className="w-4 h-4" /> : <Lock className="w-4 h-4 text-amber-400" />}
                    </div>
                    <span>{t.kitchen}</span>
                  </div>
                  {currentView === 'kitchen' && <span className="text-orange-600 font-bold text-xs">Active</span>}
                </button>

                <button
                  onClick={() => {
                    onViewChange('admin');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border text-xs font-extrabold transition-all ${
                    currentView === 'admin'
                      ? 'bg-orange-50 border-orange-200 text-orange-900 shadow-2xs'
                      : 'bg-zinc-50 border-zinc-200/80 text-zinc-700 hover:bg-zinc-100'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-xl bg-zinc-800 text-white">
                      {isAdminAuthenticated ? <LayoutDashboard className="w-4 h-4" /> : <Lock className="w-4 h-4 text-amber-400" />}
                    </div>
                    <span>{t.admin}</span>
                  </div>
                  {currentView === 'admin' && <span className="text-orange-600 font-bold text-xs">Active</span>}
                </button>
              </div>

              {/* Gmail / Google Account Card */}
              <div className="space-y-2">
                <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider block">Google OAuth Account</span>
                <button
                  onClick={() => {
                    onOpenGoogleAuth();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 p-3 rounded-2xl flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center space-x-3 overflow-hidden">
                    {googleUser ? (
                      googleUser.picture ? (
                        <img src={googleUser.picture} alt="" className="w-9 h-9 rounded-full border-2 border-emerald-500 shrink-0" />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-emerald-500 text-white font-bold flex items-center justify-center shrink-0">
                          {googleUser.name.charAt(0)}
                        </div>
                      )
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-white border border-zinc-200 flex items-center justify-center shrink-0">
                        <svg className="w-5 h-5" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                          <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.15C3.26 21.36 7.37 24 12 24z" />
                          <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.15 0 9.99 0 12s.45 3.85 1.24 5.42l4.04-3.15z" />
                          <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.37 0 3.26 2.64 1.24 6.58l4.04 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
                        </svg>
                      </div>
                    )}
                    <div className="overflow-hidden">
                      <span className="text-xs font-black text-zinc-900 block truncate">
                        {googleUser ? googleUser.name : 'Sign in with Gmail'}
                      </span>
                      <span className="text-[11px] text-zinc-500 font-medium block truncate">
                        {googleUser ? googleUser.email : 'Google OAuth Loyalty'}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-bold text-orange-600 shrink-0">
                    {googleUser ? 'Manage' : 'Sign In →'}
                  </span>
                </button>
              </div>

              {/* Table QR Selector */}
              {currentView === 'customer' && (
                <div className="space-y-2">
                  <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider block">Table Ordering</span>
                  <button
                    onClick={() => {
                      onOpenQRScanner();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full bg-orange-50 hover:bg-orange-100 border border-orange-200/90 p-3 rounded-2xl flex items-center justify-between text-left transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-xl bg-orange-500 text-white">
                        <QrCode className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-black text-orange-950 block">Table #{tableNumber || 1} Selected</span>
                        <span className="text-[11px] text-orange-800 font-medium block">Scan or Change Table QR</span>
                      </div>
                    </div>
                  </button>
                </div>
              )}

              {/* Location & Contact Info */}
              <div className="space-y-2">
                <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider block">Prime Restaurant Contacts</span>
                
                <button
                  onClick={() => {
                    onOpenLocation();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 p-3 rounded-2xl flex items-center justify-between transition-colors text-left"
                >
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-xl bg-zinc-800 text-orange-400">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-black text-zinc-900 block">Samarkand, Uzbekistan</span>
                      <span className="text-[11px] text-zinc-500 block">Map & Directions</span>
                    </div>
                  </div>
                </button>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <a
                    href="tel:+998947531722"
                    className="p-2.5 bg-zinc-50 hover:bg-orange-50 border border-zinc-200 rounded-xl flex items-center space-x-2 text-xs font-bold text-zinc-800 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                    <span className="truncate">+998 94...</span>
                  </a>
                  <a
                    href="https://instagram.com/prime_cafe_bulvar"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 bg-zinc-50 hover:bg-pink-50 border border-zinc-200 rounded-xl flex items-center space-x-2 text-xs font-bold text-zinc-800 transition-colors"
                  >
                    <Instagram className="w-3.5 h-3.5 text-pink-600 shrink-0" />
                    <span className="truncate">Instagram</span>
                  </a>
                </div>
              </div>

            </div>

            {/* Bottom Footer */}
            <div className="pt-4 border-t border-zinc-100 text-center space-y-1">
              <p className="text-[11px] font-extrabold text-zinc-800">Prime Restaurant • Samarkand</p>
              <p className="text-[10px] text-zinc-400">Digital Menu & KDS System v2.0</p>
            </div>

          </div>
        </div>
      )}
    </>
  );
};


import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import { db } from './db';

export type StaffRole = 'admin' | 'kitchen';

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 16) {
  throw new Error(
    'JWT_SECRET is not set (or too short). Generate one with: openssl rand -base64 48, and put it in .env'
  );
}

const SESSION_COOKIE_NAME = 'session';
const SESSION_TTL = '8h';
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

interface SessionPayload {
  role: StaffRole;
}

export function signSession(role: StaffRole): string {
  return jwt.sign({ role } as SessionPayload, JWT_SECRET as string, { expiresIn: SESSION_TTL });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET as string) as SessionPayload;
  } catch {
    return null;
  }
}

function getLockoutRow(role: StaffRole) {
  return db.prepare('SELECT failed_count, locked_until FROM login_attempts WHERE role = ?').get(role) as
    | { failed_count: number; locked_until: string | null }
    | undefined;
}

export function isLockedOut(role: StaffRole): { locked: boolean; retryAfterSeconds?: number } {
  const row = getLockoutRow(role);
  if (!row || !row.locked_until) return { locked: false };
  const until = new Date(row.locked_until).getTime();
  const now = Date.now();
  if (until > now) {
    return { locked: true, retryAfterSeconds: Math.ceil((until - now) / 1000) };
  }
  return { locked: false };
}

export function recordFailedAttempt(role: StaffRole) {
  const row = getLockoutRow(role);
  const nextCount = (row?.failed_count || 0) + 1;
  let lockedUntil: string | null = row?.locked_until || null;
  if (nextCount >= MAX_FAILED_ATTEMPTS) {
    lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60_000).toISOString();
  }
  db.prepare(
    `INSERT INTO login_attempts (role, failed_count, locked_until) VALUES (?, ?, ?)
     ON CONFLICT(role) DO UPDATE SET failed_count = ?, locked_until = ?`
  ).run(role, nextCount, lockedUntil, nextCount, lockedUntil);
}

export function clearFailedAttempts(role: StaffRole) {
  db.prepare(
    `INSERT INTO login_attempts (role, failed_count, locked_until) VALUES (?, 0, NULL)
     ON CONFLICT(role) DO UPDATE SET failed_count = 0, locked_until = NULL`
  ).run(role);
}

export function verifyPassword(role: StaffRole, password: string): boolean {
  const row = db.prepare('SELECT password_hash FROM staff_accounts WHERE role = ?').get(role) as
    | { password_hash: string }
    | undefined;
  if (!row) return false;
  return bcrypt.compareSync(password, row.password_hash);
}

export function setPassword(role: StaffRole, newPassword: string) {
  const hash = bcrypt.hashSync(newPassword, 12);
  db.prepare('UPDATE staff_accounts SET password_hash = ?, updated_at = ? WHERE role = ?').run(
    hash,
    new Date().toISOString(),
    role
  );
}

const isProd = process.env.NODE_ENV === 'production';

export function setSessionCookie(res: Response, role: StaffRole) {
  const token = signSession(role);
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true, // not readable by client-side JS -> not stealable via XSS
    secure: isProd, // only sent over HTTPS in production
    sameSite: 'lax',
    maxAge: 8 * 60 * 60 * 1000
  });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(SESSION_COOKIE_NAME);
}

// Express middleware factory: require a valid session cookie for the given role(s).
export function requireRole(...allowed: StaffRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const token = req.cookies?.[SESSION_COOKIE_NAME];
    if (!token) {
      res.status(401).json({ error: 'Not authenticated' });
      return;
    }
    const payload = verifySession(token);
    if (!payload || !allowed.includes(payload.role)) {
      res.status(403).json({ error: 'Not authorized' });
      return;
    }
    next();
  };
}

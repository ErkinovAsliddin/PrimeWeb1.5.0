import { z } from 'zod';

// Every field a client can send is validated and bounded here. This is what
// stops malformed/malicious payloads (huge strings, wrong types, negative
// prices, XSS payloads in text fields, etc.) from ever reaching the database.

const safeText = (max: number) => z.string().trim().min(1).max(max);

export const customizationOptionSchema = z.object({
  id: z.string().max(64),
  name: safeText(120),
  price: z.number().finite().min(0).max(100000)
});

export const customizationGroupSchema = z.object({
  id: z.string().max(64),
  title: safeText(120),
  required: z.boolean(),
  maxSelect: z.number().int().min(1).max(20).optional(),
  options: z.array(customizationOptionSchema).max(30)
});

export const menuItemCreateSchema = z.object({
  name: safeText(120),
  description: z.string().trim().max(2000).optional().default(''),
  price: z.number().finite().min(0).max(1_000_000),
  category: z.enum(['appetizers', 'mains', 'drinks', 'desserts', 'specials']),
  image: z.string().url().max(2000).optional(),
  stock: z.number().int().min(0).max(100000).optional().default(20),
  dietary: z.array(z.enum(['vegetarian', 'vegan', 'gluten-free', 'halal', 'spicy', 'chef-recommendation'])).max(10).optional().default([]),
  prepTimeMinutes: z.number().int().min(0).max(600).optional().default(12),
  customizations: z.array(customizationGroupSchema).max(20).optional().default([])
});

export const menuItemUpdateSchema = menuItemCreateSchema.partial().extend({
  isAvailable: z.boolean().optional(),
  stockReason: z.enum(['restock', 'manual_adjustment', 'spoilage', 'customer_order']).optional()
});

const selectedCustomizationSchema = z.object({
  groupTitle: safeText(120),
  optionName: safeText(120),
  price: z.number().finite().min(0).max(100000)
});

const cartItemSchema = z.object({
  cartItemId: z.string().max(100),
  menuItem: z.object({ id: z.string().max(64) }).passthrough(),
  quantity: z.number().int().min(1).max(50),
  selectedCustomizations: z.array(selectedCustomizationSchema).max(30).default([]),
  specialInstructions: z.string().trim().max(500).optional(),
  itemTotal: z.number().finite().min(0).max(1_000_000)
});

export const orderCreateSchema = z.object({
  tableNumber: z.number().int().min(1).max(9999),
  customerName: z.string().trim().max(120).optional(),
  customerPhoneOrEmail: z.string().trim().max(200).optional(),
  items: z.array(cartItemSchema).min(1).max(100),
  subtotal: z.number().finite().min(0).max(10_000_000),
  tax: z.number().finite().min(0).max(10_000_000),
  serviceCharge: z.number().finite().min(0).max(10_000_000),
  discount: z.number().finite().min(0).max(10_000_000).optional().default(0),
  totalAmount: z.number().finite().min(0).max(10_000_000),
  loyaltyPointsRedeemed: z.number().int().min(0).max(10_000_000).optional().default(0),
  paymentMethod: z.enum(['cash', 'card', 'loyalty_points', 'pay_at_counter']).optional().default('pay_at_counter'),
  orderNote: z.string().trim().max(500).optional()
});

export const orderStatusUpdateSchema = z.object({
  status: z.enum(['pending', 'preparing', 'ready', 'served', 'paid', 'cancelled']).optional(),
  paymentStatus: z.enum(['unpaid', 'paid']).optional()
}).refine(d => d.status || d.paymentStatus, { message: 'status or paymentStatus is required' });

export const tableCreateSchema = z.object({
  tableNumber: z.number().int().min(1).max(9999),
  capacity: z.number().int().min(1).max(50).optional().default(4)
});

export const loyaltyRegisterSchema = z.object({
  name: safeText(120),
  phoneOrEmail: z.string().trim().min(3).max(200),
  confirmationCode: z.string().trim().max(20).optional()
});

export const loginSchema = z.object({
  password: z.string().min(1).max(200)
});

export const changePasswordSchema = z.object({
  newPassword: z.string().min(4).max(200)
});

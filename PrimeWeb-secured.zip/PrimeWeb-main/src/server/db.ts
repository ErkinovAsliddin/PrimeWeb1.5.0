import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_TABLES, INITIAL_LOYALTY_MEMBERS } from '../data/mockData';

// --------------------------------------------------------------------------
// Persistent database (SQLite file on disk). Replaces the old in-memory
// arrays that lost all data on every server restart/deploy/crash.
//
// The DB file path is configurable via DATABASE_PATH so it can point at a
// mounted volume in Docker / a persistent disk on the VPS.
// --------------------------------------------------------------------------

const DATA_DIR = process.env.DATABASE_DIR || path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_PATH = process.env.DATABASE_PATH || path.join(DATA_DIR, 'restaurant.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL'); // safer/faster concurrent writes, and crash-resistant
db.pragma('foreign_keys = ON');

function tableExists(name: string): boolean {
  const row = db
    .prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`)
    .get(name);
  return !!row;
}

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS menu_items (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      table_number INTEGER NOT NULL,
      data TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tables (
      table_number INTEGER PRIMARY KEY,
      data TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS loyalty_members (
      id TEXT PRIMARY KEY,
      phone_or_email TEXT NOT NULL,
      data TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_logs (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    -- Admin/kitchen accounts. Passwords are always stored as bcrypt hashes,
    -- never plaintext. There is deliberately no "read password back" path.
    CREATE TABLE IF NOT EXISTS staff_accounts (
      role TEXT PRIMARY KEY, -- 'admin' | 'kitchen'
      password_hash TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- Idempotency keys so a retried/duplicated "place order" network request
    -- can never create two orders for the same submission.
    CREATE TABLE IF NOT EXISTS idempotency_keys (
      key TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    -- Login attempt tracking for basic brute-force lockout, in addition to
    -- the rate limiter in server.ts.
    CREATE TABLE IF NOT EXISTS login_attempts (
      role TEXT PRIMARY KEY,
      failed_count INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT
    );
  `);
}

migrate();

function seedIfEmpty() {
  const menuCount = (db.prepare('SELECT COUNT(*) as c FROM menu_items').get() as { c: number }).c;
  if (menuCount === 0) {
    const insert = db.prepare('INSERT INTO menu_items (id, data) VALUES (?, ?)');
    const tx = db.transaction((items: typeof INITIAL_MENU_ITEMS) => {
      for (const item of items) insert.run(item.id, JSON.stringify(item));
    });
    tx(INITIAL_MENU_ITEMS);
  }

  const orderCount = (db.prepare('SELECT COUNT(*) as c FROM orders').get() as { c: number }).c;
  if (orderCount === 0) {
    const insert = db.prepare('INSERT INTO orders (id, table_number, data, created_at) VALUES (?, ?, ?, ?)');
    const tx = db.transaction((items: typeof INITIAL_ORDERS) => {
      for (const o of items) insert.run(o.id, o.tableNumber, JSON.stringify(o), o.createdAt);
    });
    tx(INITIAL_ORDERS);
  }

  const tableCount = (db.prepare('SELECT COUNT(*) as c FROM tables').get() as { c: number }).c;
  if (tableCount === 0) {
    const insert = db.prepare('INSERT INTO tables (table_number, data) VALUES (?, ?)');
    const tx = db.transaction((items: typeof INITIAL_TABLES) => {
      for (const t of items) insert.run(t.tableNumber, JSON.stringify(t));
    });
    tx(INITIAL_TABLES);
  }

  const loyaltyCount = (db.prepare('SELECT COUNT(*) as c FROM loyalty_members').get() as { c: number }).c;
  if (loyaltyCount === 0) {
    const insert = db.prepare('INSERT INTO loyalty_members (id, phone_or_email, data) VALUES (?, ?, ?)');
    const tx = db.transaction((items: typeof INITIAL_LOYALTY_MEMBERS) => {
      for (const l of items) insert.run(l.id, l.phoneOrEmail.toLowerCase(), JSON.stringify(l));
    });
    tx(INITIAL_LOYALTY_MEMBERS);
  }
}

seedIfEmpty();

// Seed the admin/kitchen accounts from environment variables ONLY on first
// boot (i.e. if no account row exists yet). After that, passwords are
// changed through the authenticated "change password" endpoint, which
// re-hashes and updates the row — the .env values are just the bootstrap.
function seedStaffAccounts() {
  const adminRow = db.prepare(`SELECT role FROM staff_accounts WHERE role = 'admin'`).get();
  if (!adminRow) {
    const initialAdminPassword = process.env.ADMIN_INITIAL_PASSWORD;
    if (!initialAdminPassword) {
      throw new Error(
        'ADMIN_INITIAL_PASSWORD is not set. Set it in your .env before first run so an admin account can be created.'
      );
    }
    const hash = bcrypt.hashSync(initialAdminPassword, 12);
    db.prepare(`INSERT INTO staff_accounts (role, password_hash, updated_at) VALUES ('admin', ?, ?)`).run(
      hash,
      new Date().toISOString()
    );
  }

  const kitchenRow = db.prepare(`SELECT role FROM staff_accounts WHERE role = 'kitchen'`).get();
  if (!kitchenRow) {
    const initialKitchenPin = process.env.KITCHEN_INITIAL_PIN;
    if (!initialKitchenPin) {
      throw new Error(
        'KITCHEN_INITIAL_PIN is not set. Set it in your .env before first run so a kitchen account can be created.'
      );
    }
    const hash = bcrypt.hashSync(initialKitchenPin, 12);
    db.prepare(`INSERT INTO staff_accounts (role, password_hash, updated_at) VALUES ('kitchen', ?, ?)`).run(
      hash,
      new Date().toISOString()
    );
  }
}

seedStaffAccounts();

export function backupNow(): string {
  const backupDir = path.join(DATA_DIR, 'backups');
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupPath = path.join(backupDir, `restaurant-${stamp}.db`);
  db.backup(backupPath).then(() => {
    // no-op; backup is async under the hood in better-sqlite3's API surface
  });
  return backupPath;
}

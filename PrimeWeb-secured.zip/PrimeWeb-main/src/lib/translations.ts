export type Language = 'uz' | 'ru' | 'en';

export interface LocalizedDish {
  name: { uz: string; ru: string };
  description: { uz: string; ru: string };
  customizations?: Record<string, {
    title: { uz: string; ru: string };
    options: Record<string, { uz: string; ru: string }>;
  }>;
}

export const DISH_TRANSLATIONS: Record<string, LocalizedDish> = {
  m1: {
    name: {
      uz: "Truffel va Parmezan Kartoshka Fri",
      ru: "Картофель Фри с Трюфелем и Пармезаном"
    },
    description: {
      uz: "Haqiqiy qora truffel yog'i, yangi qirilgan Parmezan pishlog'i va sarimsoq sousi bilan qarsillama kartoshka fri.",
      ru: "Хрустящий картофель фри в настоящем черном трюфельном масле с тертым пармезаном и чесночным айоли."
    },
    customizations: {
      dip: {
        title: { uz: "Sousni tanlang", ru: "Выберите соус" },
        options: {
          d1: { uz: "Sarimsoqli Aioli", ru: "Чесночный Айоли" },
          d2: { uz: "Achchiq Sriracha Mayonez", ru: "Острый Майонез Шрирача" },
          d3: { uz: "Truffelli Ketchup", ru: "Трюфельный Кетчуп" }
        }
      }
    }
  },
  m2: {
    name: {
      uz: "Qarsillama Kalamar Fritti",
      ru: "Хрустящие Кальмары Фритти"
    },
    description: {
      uz: "Oltin rangda qovurilgan kalamar halqalari, zesty limon va marinara sousi bilan.",
      ru: "Кольца кальмара в золотистой корочке с лимоном и соусом маринара."
    },
    customizations: {
      'dip-calamari': {
        title: { uz: "Qo'shimcha sous", ru: "Дополнительный соус" },
        options: {
          c1: { uz: "Marinara sousi", ru: "Соус Маринара" },
          c2: { uz: "Dudlangan Xalapenyo Mayonez", ru: "Копченый Майонез Халапеньо" }
        }
      }
    }
  },
  m3: {
    name: {
      uz: "Burrata Pishlog'i va Pomidor",
      ru: "Буррата с Томатами и Песто"
    },
    description: {
      uz: "Kaymoqli Burrata pishlog'i, organik pomidorlar, rayhonli pesto va qovurilgan qarag'ay yong'og'i.",
      ru: "Сливочный сыр буррата с томатами, соусом песто и кедровыми орешками."
    }
  },
  m4: {
    name: {
      uz: "Wagyu Go'shtli Smesh Burger",
      ru: "Смаш-Бургер с Говядиной Вагю"
    },
    description: {
      uz: "Ikkita 100% Wagyu mol go'shti kotleti, erigan cheddar pishlog'i, karamellangan piyoz va maxsus burger sousi.",
      ru: "Двойная котлета из говядины Вагю, сыр чеддер, карамелизованный лук и фирменный соус."
    },
    customizations: {
      bun: {
        title: { uz: "Bulochka turi", ru: "Выбор булочки" },
        options: {
          b1: { uz: "Briosht Bulochka", ru: "Булочка Бриошь" },
          b2: { uz: "Glyutensiz Bulochka", ru: "Безглютеновая Булочка" },
          b3: { uz: "Salat Bargi O'rami (Past Uglevod)", ru: "В Салатном Листе (Low Carb)" }
        }
      },
      addons: {
        title: { uz: "Qo'shimcha masalliqlar", ru: "Дополнительные топпинги" },
        options: {
          a1: { uz: "Dudlangan Qarsillama Bekon", ru: "Хрустящий Бекон" },
          a2: { uz: "Qovurilgan Tuxum", ru: "Жареное Яйцо" },
          a3: { uz: "Qo'shimcha Wagyu Kotlet", ru: "Дополнительная Котлета Вагю" },
          a4: { uz: "Avokado Bo'laklari", ru: "Авокадо" }
        }
      }
    }
  },
  m5: {
    name: {
      uz: "Otin Pechda Pishirilgan Motsarella Pitssa",
      ru: "Пицца Маргарита на Дровах"
    },
    description: {
      uz: "San Marzano pomidor sousi, yangi motsarella pishlog'i va xushbo'y rayhon barglari.",
      ru: "Томатный соус Сан-Марцано, свежая моцарелла и ароматный базилик."
    },
    customizations: {
      crust: {
        title: { uz: "Xamir turi", ru: "Тип теста" },
        options: {
          cr1: { uz: "Neapolitan Yumshoq Xamir", ru: "Неаполитанское Тесто" },
          cr2: { uz: "Qarsillama Yupqa Xamir", ru: "Хрустящее Тонкое Тесто" },
          cr3: { uz: "Glyutensiz Asos", ru: "Безглютеновая Основа" }
        }
      }
    }
  },
  m6: {
    name: {
      uz: "Qovurilgan Atlantika Somon Balig'i",
      ru: "Атлантический Лосось на Гриле"
    },
    description: {
      uz: "Qarsillama terili somon balig'i fillet, za'faronli rizotto, sparja va sarimsoqli krem sous.",
      ru: "Филе лосося с хрустящей корочкой, шафрановым ризотто, спаржей и сливочным соусом."
    }
  },
  m7: {
    name: {
      uz: "Achchiq Tay Rayhonli Ugra (Pad Krapow)",
      ru: "Острая Тайская Лапша с Базиликом"
    },
    description: {
      uz: "Tovuq go'shti yoki tofu, Tay qalampiri, sarimsoq va guruch ugrasi bilan qovurilgan maxsus taom.",
      ru: "Обжаренная рисовая лапша с курицей или тофу, острым перцем, чесноком и базиликом."
    },
    customizations: {
      protein: {
        title: { uz: "Go'sht / Oqsil turini tanlang", ru: "Выберите белок" },
        options: {
          p1: { uz: "Tovuq Ko'kragi", ru: "Куриная Грудка" },
          p2: { uz: "Organik Tofu va Qo'ziqorin", ru: "Органический Тофу и Грибы" },
          p3: { uz: "Tigr Krevetkalar", ru: "Тигровые Креветки" }
        }
      },
      spice: {
        title: { uz: "Achchiqlik darajasi", ru: "Уровень остроты" },
        options: {
          s1: { uz: "Yumshoq (1 Qalampir)", ru: "Слабоострый (1 Перец)" },
          s2: { uz: "O'rtacha Tay (2 Qalampir)", ru: "Средний Тайский (2 Перца)" },
          s3: { uz: "O'tkir Achchiq (3 Qalampir 🔥)", ru: "Острый (3 Перца 🔥)" }
        }
      }
    }
  },
  m8: {
    name: {
      uz: "Oshpazdan Dimlangan Mol Qovurg'asi",
      ru: "Томленые Говяжьи Ребрышки от Шефа"
    },
    description: {
      uz: "12 soat davomida dimlangan yumshoq mol qovurg'asi, kartoshka pyuresi va pishirilgan sabzavotlar.",
      ru: "Говяжьи ребрышки 12-часового томления с картофельным пюре и запеченными овощами."
    }
  },
  m9: {
    name: {
      uz: "Yuzu va Ajdar Mevali Muzli Ichimlik",
      ru: "Освежающий Лимонад Юдзу и Драгонфрут"
    },
    description: {
      uz: "Yapon Yuzu tsitrus sharbati, pushti ajdar mevasi va yangi yalpiz barglari bilan salqin gazlangan ichimlik.",
      ru: "Японский цитрус юдзу, розовый драгонфрут, газировка и свежая мята."
    },
    customizations: {
      sweetness: {
        title: { uz: "Shirinlik darajasi", ru: "Уровень сладости" },
        options: {
          sw1: { uz: "Odatdagidek (100%)", ru: "Обычный (100%)" },
          sw2: { uz: "Kamroq shirin (50%)", ru: "Менее сладкий (50%)" },
          sw3: { uz: "Shakarsiz (0%)", ru: "Без сахара (0%)" }
        }
      }
    }
  },
  m10: {
    name: {
      uz: "Muzli Kofe Cold Brew",
      ru: "Холодный Кофе Колд Брю"
    },
    description: {
      uz: "Efiopiya kofe donalaridan 18 soat davomida damlangan muzli qahva.",
      ru: "Кофе 18-часовой холодной заварки из моносорта Эфиопии."
    },
    customizations: {
      milk: {
        title: { uz: "Sut turi", ru: "Выбор молока" },
        options: {
          m1: { uz: "Oddiy sut", ru: "Цельное Молоко" },
          m2: { uz: "Suli suti", ru: "Овсяное Молоко" },
          m3: { uz: "Bodom suti", ru: "Миндальное Молоко" }
        }
      }
    }
  },
  m11: {
    name: {
      uz: "Marakuya va Matcha Latte",
      ru: "Матча Латте с Маракуйей"
    },
    description: {
      uz: "Yapon yashil choyi matcha, yangi marakuya pyuresi va suli suti bilan.",
      ru: "Японский зеленый чай матча со свежим пюре маракуйи и овсяным молоком."
    }
  },
  m12: {
    name: {
      uz: "Belgiya Shokoladli Lava Keki",
      ru: "Бельгийский Шоколадный Фондан"
    },
    description: {
      uz: "Ichida erigan Belgiya shokoladi bo'lgan issiq tort, vanil muzqaymoq va mevalar bilan.",
      ru: "Теплый кекс с вытекающим шоколадом, ванильным джелато и ягодами."
    }
  },
  m13: {
    name: {
      uz: "Klassik Tiramisu Deserti",
      ru: "Классический Венецианский Тирамису"
    },
    description: {
      uz: "Espresso kofesiga botirilgan savoyardi pechenyesi va maskarpone kremi bilan tayyorlangan shirinlik.",
      ru: "Печенье савоярди, пропитанное эспрессо, со сливочным кремом маскарпоне."
    }
  }
};

export function getLocalizedMenuItem<T extends { id: string; name: string; description: string; customizations?: any[] }>(
  item: T,
  lang: Language
): T {
  if (lang === 'en') return item;
  const loc = DISH_TRANSLATIONS[item.id];
  if (!loc) return item;

  const newCustomizations = item.customizations?.map(group => {
    const groupLoc = loc.customizations?.[group.id];
    const newTitle = groupLoc?.title[lang] || group.title;
    const newOptions = group.options.map((opt: any) => {
      const optLoc = groupLoc?.options?.[opt.id];
      return {
        ...opt,
        name: optLoc ? optLoc[lang] : opt.name
      };
    });
    return {
      ...group,
      title: newTitle,
      options: newOptions
    };
  });

  return {
    ...item,
    name: loc.name[lang] || item.name,
    description: loc.description[lang] || item.description,
    customizations: newCustomizations
  };
}

export const translations = {
  en: {
    // Nav & Common
    appTitle: 'Prime Restaurant',
    digitalMenu: 'Digital Menu',
    kitchen: 'Kitchen Display',
    admin: 'Admin Panel',
    table: 'Table',
    changeTable: 'Change Table',
    scanQR: 'Scan QR Code',
    cart: 'Order Cart',
    loyalty: 'Loyalty Points',
    points: 'Pts',
    login: 'Login',
    logout: 'Log Out',
    googleSignIn: 'Sign in with Google',
    googleSignOut: 'Sign out Google Account',
    signedInAs: 'Signed in via Gmail',
    instagramHandle: '@prime_cafe_bulvar',
    phoneContact: '+998 94 753 17 22',
    whatsappContact: '+998 94 753 17 22',
    restaurantLocation: 'Samarkand, Prime Restaurant',
    searchPlaceholder: 'Search dishes, drinks...',
    kitchenReady: 'Kitchen Ready',
    instantTableService: 'Instant Table Service',
    instantTableServiceDesc: 'Scan, pick your favorites, and submit. Your order is sent directly to the kitchen display screen.',
    tableActive: 'Table #{num} Active',
    online: 'Online',
    noDishesFound: 'No dishes found',
    tryResetFilters: 'Try resetting search or category filters',
    added: 'Added!',
    digitalMenuDesc: 'Select dishes to send live orders directly to the kitchen table ticket queue.',
    itemOrdered: '{count} items ordered',

    // KDS Kitchen Display
    kdsTitle: 'Kitchen Display System (KDS)',
    kdsLive: 'Live',
    kdsSub: 'Item-by-item kitchen ticket preparation & ready dispatches',
    chimeOn: 'Chime ON',
    chimeMuted: 'Muted',
    pendingCount: 'Pending',
    cookingCount: 'Cooking',
    allActive: 'All Active',
    kdsClearTitle: 'Kitchen Display Clear!',
    kdsClearDesc: 'All incoming customer orders have been prepared and served.',
    itemsPrepared: 'Items Prepared',
    tapDishToCheck: 'Tap dish to check off one by one:',
    acceptStart: 'Accept Ticket & Start',
    allDoneMarkReady: 'All Items Done - Mark Ready!',
    markReady: 'Mark Ticket Ready',
    markServed: 'Mark as Served',

    // Admin Panel & Tabs
    tableMap: 'Table Map',
    tableMapDesc: 'Add or remove floor tables, view live occupancy and active orders',
    overview: 'Overview',
    ordersList: 'Orders List',
    qrPrint: 'QR Code Print',
    loyaltyMembers: 'Loyalty Members',
    todayRevenue: "Today's Revenue",
    paidOrdersTotal: 'Paid orders total',
    occupiedTables: 'Occupied Tables',
    occupancyRate: 'Table occupancy rate',
    totalOrders: 'Total Orders',
    submittedToday: 'Submitted today',
    avgOrderValue: 'Avg Order Value',
    perTableAvg: 'Per table average',
    liveTableStatus: 'Live Table Status Overview',
    viewTableMap: 'View Table Map →',
    interactiveTableLayout: 'Interactive Table Layout & Management',
    addTable: 'Add New Table',
    seats: 'Seats',
    noActiveOrder: 'No active order',
    pendingPayment: 'PENDING PAYMENT',
    eatingOccupied: 'EATING / OCCUPIED',
    printQR: 'Print QR',
    viewDetails: 'View Details',
    tableEmpty: 'Table is currently empty',
    productImage: 'Product Image',
    uploadPhotoOrSelect: 'Upload photo or select preset',
    changePhoto: 'Change Photo',
    uploadImageDirectly: 'Upload Image File Directly',
    quickSamplePhotos: 'Quick Sample Photos:',
    copyTableUrl: 'Copy Table URL',
    testTableMenu: 'Test Table Menu',
    multiDeviceSetup: '📱 Multi-Device Setup (Separate Kitchen & POS Screen Links)',
    multiDeviceSub: 'You can open these direct links on separate devices (e.g. Kitchen iPad, Cashier POS, or Customer Phones):',
    kitchenDisplayKDS: '👨‍🍳 Kitchen Display (KDS)',
    copyLink: 'Copy Link',
    kitchenLinkDesc: 'Open on tablet in kitchen to manage incoming ticket orders live.',
    customerMenuLink: '📱 Customer Digital Menu',
    customerLinkDesc: 'Table QR scan landing page for customers to order directly.',
    adminPOS: '🔒 Admin & Manager POS',
    adminPOSDesc: 'Manager portal for menu edits, stock, sales analytics, and tables.',

    // Categories
    catAll: 'All Items',
    catBirinchiTaom: 'First Course',
    catIkkinchiTaom: 'Main Course',
    catGarnir: 'Side Dish',
    catSalat: 'Salad',
    catNonushta: 'Breakfast',
    catPizza: 'Pizza',
    catIchimlik: 'Drinks',

    // Dietary
    filterAll: 'All Dietary',
    veg: 'Vegetarian',
    vegan: 'Vegan',
    glutenFree: 'Gluten-Free',
    halal: 'Halal',
    spicy: 'Spicy',
    chefChoice: 'Chef Choice',

    // Food Card & Order
    addToOrder: '+ Add',
    soldOut: 'SOLD OUT',
    onlyLeft: 'Only {count} left!',
    prepTime: '{mins}m',
    customizable: 'Customizable',
    reviewOrder: 'Review Order',
    yourCart: 'Your Order Cart',
    itemsCount: '{count} items',
    subtotal: 'Subtotal',
    tax: 'Tax & Service',
    total: 'Total',
    checkout: 'Submit Order to Kitchen',

    // Item Customizer
    specialInstructions: 'Special Instructions for Kitchen:',
    specialInstructionsPlaceholder: 'e.g., Dressing on the side, extra spicy, sauce separate...',
    required: 'Required',
    optional: 'Optional',
    free: 'Free',
    onlyLeftInStock: 'Only {count} left in kitchen stock! Order soon.',
    mins: 'mins',
    kcal: 'kcal',

    // Modals
    confirmTableTitle: 'Select Table & Confirm',
    confirmTableDesc: 'Scan Verified • Select your table number to unlock digital ordering',
    yourSeatedTable: 'Your Seated Table',
    capacityGuests: 'Capacity: {cap} Guests',
    scanVerified: 'Scan Verified',
    ordersSentToPOS: 'Orders will be sent directly to the Kitchen POS for Table #{num}',

    // Admin Auth
    adminLoginTitle: 'Admin Access Required',
    adminLoginDesc: 'Please enter manager password to access stock & table controls.',
    passwordLabel: 'Admin Password',
    passwordPlaceholder: 'Enter admin password',
    unlockAdmin: 'Unlock Admin Panel',
    invalidPassword: 'Incorrect password! Please try again.',
    locked: 'Admin Locked',

    // Kitchen Auth
    kitchenLoginTitle: 'Kitchen Staff Access Required',
    kitchenLoginDesc: 'Please enter staff PIN/password to access live order tickets.',
    kitchenPinLabel: 'Staff PIN / Password',
    kitchenPinPlaceholder: 'Enter staff PIN/password',
    unlockKitchen: 'Unlock Kitchen Display',
    invalidKitchenPin: 'Incorrect PIN! Please try again.',

    // Security & Password Management
    security: 'Security & Passwords',
    securityDesc: 'Change admin panel and kitchen display access passwords',
    adminPasswordSettingLabel: 'Admin Panel Password',
    kitchenPinSettingLabel: 'Kitchen (KDS) Access PIN / Password',
    newAdminPassPlaceholder: 'Enter new admin password',
    newKitchenPinPlaceholder: 'Enter new kitchen PIN/password',
    savePassword: 'Update Password',
    passUpdatedSuccess: 'Password updated successfully!',
    securityPrivateNotice: '🔒 Keep passwords secure. Staff will need the updated password to log in.',

    // Admin CRUD
    manageDishes: 'Menu & Stock Inventory',
    addNewDish: 'Add New Dish',
    editDish: 'Edit Dish',
    deleteDish: 'Delete Dish',
    confirmDelete: 'Are you sure you want to delete this dish?',
    dishName: 'Dish Name',
    category: 'Category',
    price: 'Price ($)',
    stock: 'Stock Count',
    description: 'Description',
    imageUrl: 'Image URL',
    saveChanges: 'Save Changes',
    cancel: 'Cancel',
    actions: 'Actions',
    inStock: 'IN STOCK',
    restock: 'Restock +10',

    // Order Statuses & Tracker
    statusPending: 'Received',
    statusPreparing: 'Cooking',
    statusReady: 'Ready',
    statusServed: 'Served',
    statusPaid: 'Paid',
    statusCancelled: 'Cancelled',
    orderReceived: 'Order Received',
    chefCooking: 'Chef is Cooking',
    readyForTable: 'Ready for Table!',
    enjoyMeal: 'Enjoy Your Meal!',
    sentStep: '1. Sent',
    cookingStep: '2. Cooking',
    readyStep: '3. Ready',
    servedStep: '4. Served',
    estMins: 'Est. {mins} mins',

    // Scanner
    scanTitle: 'Scan Table QR Code',
    scanDesc: 'Point your camera at the QR code on your table, or select your table number.',
    startCamera: 'Start Camera Scanner',
    stopCamera: 'Close Camera',
    manualSelect: 'Or Select Table Number',
    selectTable: 'Select Table #{num}',

    // Loyalty & History
    loyaltyTitle: 'Loyalty & Order History',
    welcomeBonus: '10 points for every $1 spent!',
    memberTier: '{tier} Tier Member',
    trackPointsRewards: 'Track points, rewards, and past dining receipts',
    loyaltyPoints: 'Loyalty Points',
    totalSpent: 'Total Spent',
    ordersCount: 'Orders Count',
    enterInfoAtCheckout: 'Enter Name & Phone/Email at checkout',
    earnPointsDesc: 'Instantly earn 10 points for every $1 spent and unlock exclusive dining discounts.',
    yourOrdersHistory: 'Your Orders History',
    noOrdersRecorded: 'No previous orders recorded yet.',

    // Verification & Cart
    verifyMethod: 'Verification Method (Free & Secure)',
    telegramFreeBot: '100% Free code via Telegram Bot',
    gmailFreeMail: '100% Free code via Google Mail',
    phoneSms: 'Standard SMS phone verification',
    quickVerify: '⚡ Quick Verify',
    sendCode: 'Send Code',
    customerName: 'Customer Name',
    customerNamePlaceholder: 'e.g. Alexbek',
    contactInfo: 'Contact Info (Phone/Telegram/Gmail)',
    verificationCode: 'Verification Code',
    enter4DigitCode: 'Enter 4-digit code',
    confirmCode: 'Confirm Code',
    incorrectCode: 'Incorrect verification code. Please check and try again.',
    orderSummary: 'Order Summary',
    specialNoteForKitchen: 'Special Note for Kitchen',
    kitchenNotePlaceholder: 'e.g. Please bring extra napkins and cutlery...',
    tipChef: 'Tip the Kitchen Chef & Staff',
    noTip: 'No Tip',
    submitOrderKitchen: 'Submit Order to Kitchen',
    orderPlacedSuccess: 'Order Placed Successfully!',
    paymentMethod: 'Payment Method',
    cash: 'Cash Payment',
    card: 'Credit / Debit Card',
    payCounter: 'Pay at Counter / Terminal',
    payWithPoints: 'Pay with Loyalty Points'
  },
  uz: {
    // Nav & Common
    appTitle: 'Prime Restaurant',
    digitalMenu: 'Raqamli Menyu',
    kitchen: 'Oshxona',
    admin: 'Admin Panel',
    table: 'Stol',
    changeTable: 'Stolni almashtirish',
    scanQR: 'QR kodni skanerlash',
    cart: 'Savat',
    loyalty: 'Bonus Ballar',
    points: 'Ball',
    login: 'Kirish',
    logout: 'Chiqish',
    googleSignIn: 'Google orqali kirish',
    googleSignOut: 'Google hisobidan chiqish',
    signedInAs: 'Gmail orqali kirilgan',
    instagramHandle: '@prime_cafe_bulvar',
    phoneContact: '+998 94 753 17 22',
    whatsappContact: '+998 94 753 17 22',
    restaurantLocation: 'Samarqand, Prime Restoran',
    searchPlaceholder: 'Taomlar va ichimliklarni qidirish...',
    kitchenReady: 'Oshxona Tayyor',
    instantTableService: 'Tezkor Stol Xizmati',
    instantTableServiceDesc: 'Skanerlang, sevimli taomlaringizni tanlang va yuboring. Buyurtmangiz to‘g‘ridan-to‘g‘ri oshxona ekraniga tushadi.',
    tableActive: 'Stol #{num} Faol',
    online: 'Onlayn',
    noDishesFound: 'Taomlar topilmadi',
    tryResetFilters: 'Qidiruv yoki kategoriya filtrlarini qayta tiklab ko‘ring',
    added: 'Qo‘shildi!',
    digitalMenuDesc: 'Taomlarni tanlang va ularni to‘g‘ridan-to‘g‘ri oshxona ekraniga yuboring.',
    itemOrdered: '{count} ta taom buyurtma qilindi',

    // KDS Kitchen Display
    kdsTitle: 'Oshxona Boshqaruv Tizimi (KDS)',
    kdsLive: 'Jonli',
    kdsSub: 'Taomlarni birma-bir tayyorlash va oshxona chiptalarini boshqarish',
    chimeOn: 'Ovoz Yoniq',
    chimeMuted: 'Ovozsiz',
    pendingCount: 'Kutilmoqda',
    cookingCount: 'Tayyorlanmoqda',
    allActive: 'Barchasi Faol',
    kdsClearTitle: 'Oshxona Ekrani Toza!',
    kdsClearDesc: 'Barcha kelgan mijoz buyurtmalari tayyorlandi va tortildi.',
    itemsPrepared: 'Tayyorlangan taomlar',
    tapDishToCheck: 'Birma-bir tayyor bo‘lgan taomni bosing:',
    acceptStart: 'Chiptani qabul qilish va boshlash',
    allDoneMarkReady: 'Barcha taomlar tayyor - Belgilash!',
    markReady: 'Tayyor deb belgilash',
    markServed: 'Tortildi deb belgilash',

    // Admin Panel & Tabs
    tableMap: 'Stollar Xaritasi',
    tableMapDesc: 'Zaldagi stollarni qo‘shish yoki o‘chirish, bandlik va buyurtmalarni ko‘rish',
    overview: 'Umumiy Ko‘rinish',
    ordersList: 'Buyurtmalar Ro‘yxati',
    qrPrint: 'QR Kod Chop Etish',
    loyaltyMembers: 'Sadoqatli Mijozlar',
    todayRevenue: 'Bugungi Tushum',
    paidOrdersTotal: 'To‘langan buyurtmalar jami',
    occupiedTables: 'Band Stollar',
    occupancyRate: 'Stollarning bandlik darajasi',
    totalOrders: 'Jami Buyurtmalar',
    submittedToday: 'Bugun yuborilgan',
    avgOrderValue: 'O‘rtacha Buyurtma Cheki',
    perTableAvg: 'Bitta stol uchun o‘rtacha',
    liveTableStatus: 'Jonli Stollar Holati',
    viewTableMap: 'Stollar xaritasini ko‘rish →',
    interactiveTableLayout: 'Interaktiv Stollar Joylashuvi va Boshqaruvi',
    addTable: 'Yangi Stol Qo‘shish',
    seats: 'Kishilik',
    noActiveOrder: 'Faol buyurtma yo‘q',
    pendingPayment: 'TO‘LOV KUTILMOQDA',
    eatingOccupied: 'OVQATLANMOQDA / BAND',
    printQR: 'QR Chop Etish',
    viewDetails: 'Batafsil Ko‘rish',
    tableEmpty: 'Stol hozircha bo‘sh',
    productImage: 'Taom Rasmi',
    uploadPhotoOrSelect: 'Rasm yuklang yoki tayyorini tanlang',
    changePhoto: 'Rasmni O‘zgartirish',
    uploadImageDirectly: 'Rasmni Qurilmadan Yuklash',
    quickSamplePhotos: 'Tayyor Namunalar:',
    copyTableUrl: 'Stol Havolasini Nusxalash',
    testTableMenu: 'Stol Menyusini Sinash',
    multiDeviceSetup: '📱 Ko‘p Qurilmali Sozlama (Alohida Oshxona va Kassa Havolalari)',
    multiDeviceSub: 'Ushbu havolalarni alohida qurilmalarda (planshet, kassa yoki mijoz telefonida) ochishingiz mumkin:',
    kitchenDisplayKDS: '👨‍🍳 Oshxona Ekrani (KDS)',
    copyLink: 'Linkni Nusxalash',
    kitchenLinkDesc: 'Oshxona planshetida buyurtma chiptalarini jonli boshqarish uchun oching.',
    customerMenuLink: '📱 Mijoz Raqamli Menyusi',
    customerLinkDesc: 'Mijozlar stol QR kodini skanerlab buyurtma berishi uchun havola.',
    adminPOS: '🔒 Admin va Menejer POS',
    adminPOSDesc: 'Menejer uchun menyu, ombor va savdo tahlili portali.',

    // Categories
    catAll: 'Barcha Taomlar',
    catBirinchiTaom: 'Birinchi taom',
    catIkkinchiTaom: 'Ikkinchi taom',
    catGarnir: 'Garnir',
    catSalat: 'Salat',
    catNonushta: 'Nonushta',
    catPizza: 'Pizza',
    catIchimlik: 'Ichimlik',

    // Dietary
    filterAll: 'Barcha turlar',
    veg: 'Vegetarian',
    vegan: 'Vegan',
    glutenFree: 'Glyutensiz',
    halal: 'Halol',
    spicy: 'Achchiq',
    chefChoice: 'Oshpaz tavsiyasi',

    // Food Card & Order
    addToOrder: '+ Qo‘shish',
    soldOut: 'TUGADI',
    onlyLeft: 'Faqat {count} ta qoldi!',
    prepTime: '{mins}m',
    customizable: 'Tanlovli',
    reviewOrder: 'Buyurtmani ko‘rish',
    yourCart: 'Sizning savatingiz',
    itemsCount: '{count} ta taom',
    subtotal: 'Oraliq summa',
    tax: 'Soliq va Xizmat',
    total: 'Jami',
    checkout: 'Oshxonaga yuborish',

    // Item Customizer
    specialInstructions: 'Oshxona uchun Maxsus Eslatma:',
    specialInstructionsPlaceholder: 'masalan, Sous alohida bo‘lsin, achchiqroq bo‘lsin...',
    required: 'Majburiy',
    optional: 'Ixtiyoriy',
    free: 'Bepul',
    onlyLeftInStock: 'Oshxona omborida faqat {count} ta qoldi! Tezda buyurtma bering.',
    mins: 'daqiqa',
    kcal: 'kkal',

    // Modals
    confirmTableTitle: 'Stolni Tanlang va Tasdiqlang',
    confirmTableDesc: 'Skaner Tasdiqlandi • Raqamli menyuni ochish uchun stol raqamini tanlang',
    yourSeatedTable: 'Sizning Stolingiz',
    capacityGuests: 'Sig‘imi: {cap} Kishilik',
    scanVerified: 'Skaner Tasdiqlandi',
    ordersSentToPOS: 'Buyurtmalar Stol #{num} uchun to‘g‘ridan-to‘g‘ri oshxonaga yuboriladi',

    // Admin Auth
    adminLoginTitle: 'Admin Kirish Tizimi',
    adminLoginDesc: 'Menyu va stollarni boshqarish uchun admin parolini kiriting.',
    passwordLabel: 'Admin Paroli',
    passwordPlaceholder: 'Admin parolini kiriting',
    unlockAdmin: 'Admin panelga kirish',
    invalidPassword: 'Parol noto‘g‘ri! Qaytadan urinib ko‘ring.',
    locked: 'Yopiq Admin',

    // Kitchen Auth
    kitchenLoginTitle: 'Oshxona Xodimlari Kirishi',
    kitchenLoginDesc: 'Buyurtmalarni ko‘rish uchun xodim parolini kiriting.',
    kitchenPinLabel: 'Xodim PIN KODI / Paroli',
    kitchenPinPlaceholder: 'Xodim parolini kiriting',
    unlockKitchen: 'Oshxona panelini ochish',
    invalidKitchenPin: 'PIN kod noto‘g‘ri! Qaytadan urinib ko‘ring.',

    // Security & Password Management
    security: 'Xavfsizlik va Parollar',
    securityDesc: 'Admin panel va oshxona kirish parollarini o‘zgartirish',
    adminPasswordSettingLabel: 'Admin Panel Paroli',
    kitchenPinSettingLabel: 'Oshxona (KDS) Kirish kodi / Paroli',
    newAdminPassPlaceholder: 'Yangi admin parolini kiriting',
    newKitchenPinPlaceholder: 'Yangi oshxona parolini kiriting',
    savePassword: 'Parolni saqlash',
    passUpdatedSuccess: 'Parol muvaffaqiyatli yangilandi!',
    securityPrivateNotice: '🔒 Parollarni sir saqlang. Xodimlar kirish uchun yangilangan paroldan foydalanadilar.',

    // Admin CRUD
    manageDishes: 'Menyu va Ombor Boshqaruvi',
    addNewDish: 'Yangi taom qo‘shish',
    editDish: 'Taomni tahrirlash',
    deleteDish: 'Taomni o‘chirish',
    confirmDelete: 'Ushbu taomni o‘chirib tashlamoqchimisiz?',
    dishName: 'Taom nomi',
    category: 'Kategoriya',
    price: 'Narxi ($)',
    stock: 'Ombor soni',
    description: 'Tavsifi',
    imageUrl: 'Rasm havolasi (URL)',
    saveChanges: 'Saqlash',
    cancel: 'Bekor qilish',
    actions: 'Amallar',
    inStock: 'MAVJUD',
    restock: 'To‘ldirish +10',

    // Order Statuses & Tracker
    statusPending: 'Qabul qilindi',
    statusPreparing: 'Tayyorlanmoqda',
    statusReady: 'Tayyor',
    statusServed: 'Tortildi',
    statusPaid: 'To‘landi',
    statusCancelled: 'Bekor qilindi',
    orderReceived: 'Buyurtma Qabul Qilindi',
    chefCooking: 'Oshpaz Tayyorlamoqda',
    readyForTable: 'Stolga Tayyor!',
    enjoyMeal: 'Yoqimli Ishtaha!',
    sentStep: '1. Yuborildi',
    cookingStep: '2. Pishmoqda',
    readyStep: '3. Tayyor',
    servedStep: '4. Tortildi',
    estMins: 'Taxminan {mins} m',

    // Scanner
    scanTitle: 'Stol QR Kodini Skanerlang',
    scanDesc: 'Stolingizdagi QR kodga kamerani qarating yoki stol raqamini tanlang.',
    startCamera: 'Kamerani yoqish',
    stopCamera: 'Kamerani o‘chirish',
    manualSelect: 'Yoki Stol Raqamini Tanlang',
    selectTable: 'Stol #{num} ni tanlash',

    // Loyalty & History
    loyaltyTitle: 'Loyallik va Buyurtmalar Tarixi',
    welcomeBonus: 'Har $1 uchun 10 bonus ball oling!',
    memberTier: '{tier} darajali a’zo',
    trackPointsRewards: 'Ballar, mukofotlar va o‘tgan kvitansiyalarni kuzatib boring',
    loyaltyPoints: 'Bonus Ballar',
    totalSpent: 'Jami Xarajat',
    ordersCount: 'Buyurtmalar Soni',
    enterInfoAtCheckout: 'To‘lov paytida Ism va Telefon/Emailingizni kiriting',
    earnPointsDesc: 'Har $1 uchun 10 ball oling va maxsus chegirmalarga ega bo‘ling.',
    yourOrdersHistory: 'Sizning Buyurtmalar Tarixingiz',
    noOrdersRecorded: 'Hali hech qanday buyurtma berilmadi.',

    // Verification & Cart
    verifyMethod: 'Tasdiqlash Usuli (Bepul va Xavfsiz)',
    telegramFreeBot: '100% Bepul kod Telegram Bot orqali',
    gmailFreeMail: '100% Bepul kod Google Mail orqali',
    phoneSms: 'Odatdagidek SMS telefon orqali',
    quickVerify: '⚡ Tezkor Tasdiqlash',
    sendCode: 'Kod Yuborish',
    customerName: 'Mijoz Ismi',
    customerNamePlaceholder: 'masalan, Alexbek',
    contactInfo: 'Aloqa Ma’lumoti (Telefon/Telegram/Gmail)',
    verificationCode: 'Tasdiqlash KODI',
    enter4DigitCode: '4 xonali kodni kiriting',
    confirmCode: 'Kodni Tasdiqlash',
    incorrectCode: 'Kod noto‘g‘ri. Tekshirib qayta urinib ko‘ring.',
    orderSummary: 'Buyurtma Xulosasi',
    specialNoteForKitchen: 'Oshxona uchun Maxsus Eslatma',
    kitchenNotePlaceholder: 'masalan, Qo‘shimcha salfetka va pichoq-sanchqi keltiring...',
    tipChef: 'Oshpaz va Xodimlarga Choychaqa (Choy puli)',
    noTip: 'Choy pulisiz',
    submitOrderKitchen: 'Buyurtmani Oshxonaga Yuborish',
    orderPlacedSuccess: 'Buyurtma Muvaffaqiyatli Qabul Qilindi!',
    paymentMethod: 'To‘lov Usuli',
    cash: 'Naqd Pul',
    card: 'Bank Kartasi',
    payCounter: 'Kassada To‘lash',
    payWithPoints: 'Bonus Ballar Bilan To‘lash'
  },
  ru: {
    // Nav & Common
    appTitle: 'Prime Restaurant',
    digitalMenu: 'Цифровое Меню',
    kitchen: 'Кухня (KDS)',
    admin: 'Панель Админа',
    table: 'Стол',
    changeTable: 'Сменить стол',
    scanQR: 'Сканировать QR',
    cart: 'Корзина',
    loyalty: 'Бонусные Баллы',
    points: 'Баллов',
    login: 'Войти',
    logout: 'Выйти',
    googleSignIn: 'Войти через Google',
    googleSignOut: 'Выйти из Google',
    signedInAs: 'Вход через Gmail',
    instagramHandle: '@prime_cafe_bulvar',
    phoneContact: '+998 94 753 17 22',
    whatsappContact: '+998 94 753 17 22',
    restaurantLocation: 'Самарканд, Ресторан Prime',
    searchPlaceholder: 'Поиск блюд и напитков...',
    kitchenReady: 'Кухня Готова',
    instantTableService: 'Быстрый Заказ на Стол',
    instantTableServiceDesc: 'Отсканируйте, выберите блюда и отправьте. Ваш заказ поступит прямо на экран кухни.',
    tableActive: 'Стол #{num} Активен',
    online: 'Онлайн',
    noDishesFound: 'Блюда не найдены',
    tryResetFilters: 'Попробуйте сбросить поиск или фильтры категорий',
    added: 'Добавлено!',
    digitalMenuDesc: 'Выберите блюда для отправки заказа прямо на экран кухни.',
    itemOrdered: 'Заказано {count} блюд',

    // KDS Kitchen Display
    kdsTitle: 'Кухонная Система Заказов (KDS)',
    kdsLive: 'В эфире',
    kdsSub: 'Пошаговая готовка блюд и управление кухонными чеками',
    chimeOn: 'Звук Вкл',
    chimeMuted: 'Без звука',
    pendingCount: 'Ожидают',
    cookingCount: 'Готовятся',
    allActive: 'Все Активные',
    kdsClearTitle: 'Экран Кухни Чист!',
    kdsClearDesc: 'Все поступившие заказы приготовлены и поданы клиентам.',
    itemsPrepared: 'Приготовлено блюд',
    tapDishToCheck: 'Нажмите на блюдо по мере готовности:',
    acceptStart: 'Принять чек и начать',
    allDoneMarkReady: 'Все блюда готовы - Отметить!',
    markReady: 'Отметить Готовым',
    markServed: 'Отметить Поданным',

    // Admin Panel & Tabs
    tableMap: 'Карта Столов',
    tableMapDesc: 'Добавление и удаление столов, просмотр занятости и заказов',
    overview: 'Общий Обзор',
    ordersList: 'Список Заказов',
    qrPrint: 'Печать QR Кодов',
    loyaltyMembers: 'Участники Лояльности',
    todayRevenue: 'Выручка За Сегодня',
    paidOrdersTotal: 'Всего оплаченных заказов',
    occupiedTables: 'Занятые Столы',
    occupancyRate: 'Уровень загрузки столов',
    totalOrders: 'Всего Заказов',
    submittedToday: 'Отправлено сегодня',
    avgOrderValue: 'Средний Чек',
    perTableAvg: 'В среднем на стол',
    liveTableStatus: 'Статус Столов в Реальном Времени',
    viewTableMap: 'Смотреть карту столов →',
    interactiveTableLayout: 'Интерактивная Схема и Управление Столами',
    addTable: 'Добавить Новый Стол',
    seats: 'Мест',
    noActiveOrder: 'Нет активного заказа',
    pendingPayment: 'ОЖИДАЕТ ОПЛАТЫ',
    eatingOccupied: 'ЗАНЯТ / ЕДЯТ',
    printQR: 'Печать QR',
    viewDetails: 'Подробнее',
    tableEmpty: 'Стол сейчас свободен',
    productImage: 'Фото Блюда',
    uploadPhotoOrSelect: 'Загрузите фото или выберите готовое',
    changePhoto: 'Изменить Фото',
    uploadImageDirectly: 'Загрузить Фото с Устройства',
    quickSamplePhotos: 'Готовые Образцы:',
    copyTableUrl: 'Скопировать Ссылку Стола',
    testTableMenu: 'Проверить Меню Стола',
    multiDeviceSetup: '📱 Настройка Нескольких Устройств (Отдельные Ссылки Кухни и Кассы)',
    multiDeviceSub: 'Вы можете открыть эти ссылки на разных устройствах (планшет на кухне, кассовый POS-терминал или телефоны гостей):',
    kitchenDisplayKDS: '👨‍🍳 Экран Кухни (KDS)',
    copyLink: 'Скопировать Ссылку',
    kitchenLinkDesc: 'Открыть на планшете кухни для управления заказами в реальном времени.',
    customerMenuLink: '📱 Цифровое Меню Гостя',
    customerLinkDesc: 'Страница заказа для клиентов после сканирования QR-кода стола.',
    adminPOS: '🔒 Панель Администратора / POS',
    adminPOSDesc: 'Портал менеджера для меню, склада, аналитики и столов.',

    // Categories
    catAll: 'Все Блюда',
    catBirinchiTaom: 'Первое блюдо',
    catIkkinchiTaom: 'Второе блюдо',
    catGarnir: 'Гарнир',
    catSalat: 'Салат',
    catNonushta: 'Завтрак',
    catPizza: 'Пицца',
    catIchimlik: 'Напитки',

    // Dietary
    filterAll: 'Все категории',
    veg: 'Вегетарианское',
    vegan: 'Веганское',
    glutenFree: 'Без глютена',
    halal: 'Халяль',
    spicy: 'Острое',
    chefChoice: 'Выбор шефа',

    // Food Card & Order
    addToOrder: '+ Добавить',
    soldOut: 'ПРОДАНО',
    onlyLeft: 'Осталось {count} шт!',
    prepTime: '{mins}м',
    customizable: 'С выбором',
    reviewOrder: 'Просмотр заказа',
    yourCart: 'Ваша Корзина',
    itemsCount: '{count} блюд',
    subtotal: 'Подытог',
    tax: 'Налог и Сервис',
    total: 'Итого',
    checkout: 'Отправить на кухню',

    // Item Customizer
    specialInstructions: 'Особые Пожелания для Кухни:',
    specialInstructionsPlaceholder: 'например, Соус отдельно, посвежее, без лука...',
    required: 'Обязательно',
    optional: 'Опционально',
    free: 'Бесплатно',
    onlyLeftInStock: 'Осталось всего {count} шт на кухне! Поспешите с заказом.',
    mins: 'мин',
    kcal: 'ккал',

    // Modals
    confirmTableTitle: 'Выберите Стол и Подтвердите',
    confirmTableDesc: 'Сканирование Подтверждено • Выберите номер стола для доступа к меню',
    yourSeatedTable: 'Ваш Стол',
    capacityGuests: 'Вместимость: {cap} Гостей',
    scanVerified: 'Сканер Подтвержден',
    ordersSentToPOS: 'Заказы будут отправлены прямо на кухню для Стола #{num}',

    // Admin Auth
    adminLoginTitle: 'Доступ Администратора',
    adminLoginDesc: 'Введите пароль администратора для управления меню и столами.',
    passwordLabel: 'Пароль Админа',
    passwordPlaceholder: 'Введите пароль админа',
    unlockAdmin: 'Войти в панель',
    invalidPassword: 'Неверный пароль! Попробуйте еще раз.',
    locked: 'Панель Заблокирована',

    // Kitchen Auth
    kitchenLoginTitle: 'Доступ для Персонала Кухни',
    kitchenLoginDesc: 'Введите PIN-код/пароль персонала для просмотра заказов.',
    kitchenPinLabel: 'PIN-код персонала / Пароль',
    kitchenPinPlaceholder: 'Введите PIN/пароль персонала',
    unlockKitchen: 'Открыть экран кухни',
    invalidKitchenPin: 'Неверный PIN! Попробуйте еще раз.',

    // Security & Password Management
    security: 'Безопасность и Пароли',
    securityDesc: 'Изменение паролей для админ-панели и экрана кухни',
    adminPasswordSettingLabel: 'Пароль Админ-Панели',
    kitchenPinSettingLabel: 'PIN/Пароль доступа к Кухне (KDS)',
    newAdminPassPlaceholder: 'Введите новый пароль админа',
    newKitchenPinPlaceholder: 'Введите новый пароль кухни',
    savePassword: 'Обновить пароль',
    passUpdatedSuccess: 'Пароль успешно обновлен!',
    securityPrivateNotice: '🔒 Храните пароли в секрете. Персонал должен использовать новый пароль для входа.',

    // Admin CRUD
    manageDishes: 'Управление Меню и Складом',
    addNewDish: 'Добавить Блюдо',
    editDish: 'Редактировать Блюдо',
    deleteDish: 'Удалить Блюдо',
    confirmDelete: 'Вы уверены, что хотите удалить это блюдо?',
    dishName: 'Название Блюда',
    category: 'Категория',
    price: 'Цена ($)',
    stock: 'Количество на складе',
    description: 'Описание',
    imageUrl: 'Ссылка на фото (URL)',
    saveChanges: 'Сохранить',
    cancel: 'Отмена',
    actions: 'Действия',
    inStock: 'В НАЛИЧИИ',
    restock: 'Пополнить +10',

    // Order Statuses & Tracker
    statusPending: 'Принят',
    statusPreparing: 'Готовится',
    statusReady: 'Готово',
    statusServed: 'Подано',
    statusPaid: 'Оплачено',
    statusCancelled: 'Отменено',
    orderReceived: 'Заказ Принят',
    chefCooking: 'Повар Готовит',
    readyForTable: 'Готово к Подаче!',
    enjoyMeal: 'Приятного Аппетита!',
    sentStep: '1. Отправлен',
    cookingStep: '2. Готовится',
    readyStep: '3. Готово',
    servedStep: '4. Подано',
    estMins: 'Около {mins} мин',

    // Scanner
    scanTitle: 'Сканировать QR код стола',
    scanDesc: 'Наведите камеру на QR код вашего стола или выберите номер стола вручную.',
    startCamera: 'Включить камеру',
    stopCamera: 'Закрыть камеру',
    manualSelect: 'Или выберите номер стола',
    selectTable: 'Выбрать Стол #{num}',

    // Loyalty & History
    loyaltyTitle: 'Лояльность и История Заказов',
    welcomeBonus: '10 бонусов за каждый потраченный $1!',
    memberTier: 'Уровень {tier}',
    trackPointsRewards: 'Отслеживайте баллы, награды и чеки предыдущих заказов',
    loyaltyPoints: 'Бонусные Баллы',
    totalSpent: 'Всего Потрачено',
    ordersCount: 'Количество Заказов',
    enterInfoAtCheckout: 'Введите имя и телефон/email при оформлении',
    earnPointsDesc: 'Получайте 10 баллов за каждый $1 и открывайте эксклюзивные скидки.',
    yourOrdersHistory: 'История Ваших Заказов',
    noOrdersRecorded: 'Предыдущих заказов пока нет.',

    // Verification & Cart
    verifyMethod: 'Способ Подтверждения (Бесплатно и Безопасно)',
    telegramFreeBot: '100% Бесплатный код через Telegram Бот',
    gmailFreeMail: '100% Бесплатный код через Google Почту',
    phoneSms: 'Стандартное SMS на телефон',
    quickVerify: '⚡ Быстрое Подтверждение',
    sendCode: 'Отправить Код',
    customerName: 'Имя Гостя',
    customerNamePlaceholder: 'например, Алексбек',
    contactInfo: 'Контактные Данные (Телефон/Telegram/Gmail)',
    verificationCode: 'Код Подтверждения',
    enter4DigitCode: 'Введите 4-значный код',
    confirmCode: 'Подтвердить Код',
    incorrectCode: 'Неверный код. Проверьте и попробуйте снова.',
    orderSummary: 'Состав Заказов',
    specialNoteForKitchen: 'Особая Заметка для Кухни',
    kitchenNotePlaceholder: 'например, Принесите дополнительные салфетки...',
    tipChef: 'Чаевые Поварам и Персоналу',
    noTip: 'Без чаевых',
    submitOrderKitchen: 'Отправить Заказ на Кухню',
    orderPlacedSuccess: 'Заказ Успешно Оформлен!',
    paymentMethod: 'Способ Оплаты',
    cash: 'Наличные',
    card: 'Банковская Карта',
    payCounter: 'Оплата на Кассе',
    payWithPoints: 'Оплатить Бонусными Баллами'
  }
};



import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { ZodSchema } from 'zod';
import { OAuth2Client } from 'google-auth-library';
import {
  telegramConfigured,
  createVerificationToken,
  getVerificationStatus,
  markVerified,
  sendTelegramMessage,
  registerWebhook
} from './src/server/telegram';
import { createServer as createViteServer } from 'vite';
import { db, backupNow } from './src/server/db';
import {
  requireRole,
  verifyPassword,
  setPassword,
  setSessionCookie,
  clearSessionCookie,
  verifySession,
  isLockedOut,
  recordFailedAttempt,
  clearFailedAttempts
} from './src/server/auth';
import {
  menuItemCreateSchema,
  menuItemUpdateSchema,
  orderCreateSchema,
  orderStatusUpdateSchema,
  tableCreateSchema,
  loyaltyRegisterSchema,
  loginSchema,
  changePasswordSchema,
  googleVerifySchema,
  exchangeRateUpdateSchema,
  settingsUpdateSchema
} from './src/server/validation';
import { MenuItem, Order, Table, LoyaltyMember, InventoryLog } from './src/types';

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------------
// Real-time updates via Server-Sent Events, split into two scopes:
//  - Staff stream (admin/kitchen only, session-gated): full order details,
//    inventory, and table state, exactly like a kitchen display needs.
//  - Table-scoped stream (public but narrow): a customer only receives
//    updates for their OWN table's order status and general menu/table
//    availability — never other tables' orders or any loyalty-member data.
// The original build broadcast full orders + the entire loyalty member list
// (names/phones/emails/points) to every connected browser tab, including
// customers. That data exposure is fixed by this split.
// ---------------------------------------------------------------------------
type SSEClient = { res: Response; tableNumber?: number };
const staffClients: Response[] = [];
const tableClients: SSEClient[] = [];

function sseSend(res: Response, type: string, data: unknown) {
  res.write(`data: ${JSON.stringify({ type, data, timestamp: new Date().toISOString() })}\n\n`);
}

function broadcastStaff(type: string, data: unknown) {
  staffClients.forEach(res => {
    try {
      sseSend(res, type, data);
    } catch (e) {
      logger.error({ err: e }, 'SSE staff send error');
    }
  });
}

function broadcastTable(tableNumber: number, type: string, data: unknown) {
  tableClients
    .filter(c => c.tableNumber === tableNumber)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE table send error');
      }
    });
}

function broadcastTableAll(type: string, data: unknown) {
  tableClients.forEach(c => {
    try {
      sseSend(c.res, type, data);
    } catch (e) {
      logger.error({ err: e }, 'SSE table-all send error');
    }
  });
}

// ---------------------------------------------------------------------------
// Generic request-validation middleware. Every mutating endpoint below runs
// its body through a zod schema before touching the database. Anything that
// doesn't match the schema is rejected with 400 and never reaches business
// logic.
// ---------------------------------------------------------------------------
function validateBody<T extends ZodSchema>(schema: T) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ error: 'Invalid request data', details: result.error.flatten() });
      return;
    }
    req.body = result.data;
    next();
  };
}

// --- Data access helpers (SQLite-backed, replacing the old in-memory arrays) --
function readMenu(): MenuItem[] {
  return (db.prepare('SELECT data FROM menu_items').all() as { data: string }[]).map(r => JSON.parse(r.data));
}
function readOrders(): Order[] {
  return (db.prepare('SELECT data FROM orders ORDER BY created_at DESC').all() as { data: string }[]).map(r =>
    JSON.parse(r.data)
  );
}
function readTables(): Table[] {
  return (db.prepare('SELECT data FROM tables ORDER BY table_number ASC').all() as { data: string }[]).map(r =>
    JSON.parse(r.data)
  );
}
function readLoyalty(): LoyaltyMember[] {
  return (db.prepare('SELECT data FROM loyalty_members').all() as { data: string }[]).map(r => JSON.parse(r.data));
}
function readInventoryLogs(): InventoryLog[] {
  return (db.prepare('SELECT data FROM inventory_logs ORDER BY created_at DESC LIMIT 500').all() as {
    data: string;
  }[]).map(r => JSON.parse(r.data));
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Trust the first proxy hop (needed on Hostinger/AWS behind Nginx/ALB/Cloudflare)
  // so rate limiting and secure cookies see the real client IP/protocol.
  app.set('trust proxy', 1);

  // --- Security headers ---
  app.use(
    helmet({
      contentSecurityPolicy: isProd
        ? {
            directives: {
              defaultSrc: ["'self'"],
              imgSrc: ["'self'", 'data:', 'https:'],
              scriptSrc: ["'self'", 'https://accounts.google.com/gsi/client'],
              styleSrc: ["'self'", "'unsafe-inline'"],
              connectSrc: ["'self'", 'https://accounts.google.com'],
              frameSrc: ["'self'", 'https://accounts.google.com'],
              frameAncestors: ["'none'"]
            }
          }
        : false, // relaxed in dev so Vite HMR keeps working
      // Helmet's default 'same-origin' isolates this page's window from any
      // popup it opens, breaking the postMessage handshake Google Sign-In's
      // popup relies on (this is the exact cause of "Cannot read properties
      // of null (reading 'postMessage')"). 'same-origin-allow-popups' keeps
      // the isolation for framing/Spectre purposes but still lets an opened
      // popup talk back to us.
      crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' }
    })
  );

  // --- CORS: only allow explicitly configured origins (never "*") ---
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(o => o.trim()).filter(Boolean);
  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          callback(new Error('Not allowed by CORS'));
        }
      },
      credentials: true
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: '8mb' })); // uploaded photos are base64-encoded in the request body
  app.use(express.urlencoded({ limit: '8mb', extended: true }));
  app.use(pinoHttp({ logger, redact: ['req.headers.cookie', 'req.headers.authorization'] }));

  // --- Rate limiting ---
  app.use(
    '/api/',
    rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false })
  );
  const loginLimiter = rateLimit({
    windowMs: 60_000,
    limit: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many login attempts. Please wait a minute and try again.' }
  });
  const orderLimiter = rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false });

  // Staff real-time stream: full detail, admin/kitchen session required.
  app.get('/api/events', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    // Tells Nginx (and similar reverse proxies) not to buffer this response.
    // Without this, notifications can sit in a proxy buffer and only
    // arrive once it flushes — which looks exactly like "I have to
    // refresh to see new orders" even though the server sent them instantly.
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    staffClients.push(res);
    req.on('close', () => {
      const idx = staffClients.indexOf(res);
      if (idx !== -1) staffClients.splice(idx, 1);
    });
  });

  // Customer real-time stream: scoped to one table, no auth required (a
  // dining guest isn't logged in), but never carries other tables' data.
  app.get('/api/events/table/:tableNumber', (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).end();
      return;
    }
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    const client: SSEClient = { res, tableNumber };
    tableClients.push(client);
    req.on('close', () => {
      const idx = tableClients.indexOf(client);
      if (idx !== -1) tableClients.splice(idx, 1);
    });
  });

  const googleClientId = (process.env.GOOGLE_CLIENT_ID || '').trim().replace(/^["']|["']$/g, '');
  const googleClient = googleClientId ? new OAuth2Client(googleClientId) : null;
  if (googleClientId && !googleClientId.endsWith('.apps.googleusercontent.com')) {
    logger.warn(
      { googleClientId },
      "GOOGLE_CLIENT_ID doesn't look like a real Google OAuth Client ID (should end in .apps.googleusercontent.com) — double-check you copied the Client ID, not the Client Secret, and that there are no stray quotes/spaces in .env"
    );
  }

  // The Client ID is not secret (it's meant to be embedded in frontend JS) —
  // safe to expose here so the frontend doesn't need it hardcoded/rebuilt.
  app.get('/api/auth/google/config', (_req: Request, res: Response) => {
    res.json({ clientId: googleClientId, configured: !!googleClientId });
  });

  // Real verification: the ID token is a signed JWT from Google. We verify
  // its signature, issuer, audience (our Client ID), and expiry server-side
  // via google-auth-library — this cannot be forged by typing an email into
  // a form, unlike the old mocked flow.
  app.post(
    '/api/auth/google/verify',
    orderLimiter,
    validateBody(googleVerifySchema),
    async (req: Request, res: Response) => {
      if (!googleClient || !googleClientId) {
        res.status(503).json({
          error: 'Google Sign-In is not configured on this server yet. Set GOOGLE_CLIENT_ID in .env.'
        });
        return;
      }
      try {
        const ticket = await googleClient.verifyIdToken({
          idToken: req.body.credential,
          audience: googleClientId
        });
        const payload = ticket.getPayload();
        if (!payload || !payload.email) {
          res.status(401).json({ error: 'Invalid Google credential' });
          return;
        }
        res.json({
          id: 'google-' + payload.sub,
          email: payload.email,
          name: payload.name || payload.email.split('@')[0],
          picture: payload.picture || '',
          givenName: payload.given_name || (payload.name || '').split(' ')[0]
        });
      } catch (err: any) {
        req.log.warn(
          { err: err?.message, googleClientId },
          'Google ID token verification failed — check that GOOGLE_CLIENT_ID here matches Google Cloud Console exactly, and that your domain is in Authorized JavaScript origins'
        );
        res.status(401).json({ error: 'Could not verify Google credential' });
      }
    }
  );

  // --- TELEGRAM BOT VERIFICATION ---
  // Real verification: the customer taps "Verify with Telegram", we hand
  // them a one-time deep link to YOUR bot, they press Start there (proving
  // they control that Telegram account), and the bot's webhook marks the
  // token verified. The browser polls for that. This replaces a flow that
  // used to accept a universal bypass code and never verified anything.
  const TELEGRAM_WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || '';

  app.get('/api/auth/telegram/config', (_req: Request, res: Response) => {
    res.json({ configured: telegramConfigured });
  });

  app.post('/api/auth/telegram/start', orderLimiter, (_req: Request, res: Response) => {
    if (!telegramConfigured) {
      res.status(503).json({ error: 'Telegram verification is not configured on this server yet.' });
      return;
    }
    const { token, deepLink } = createVerificationToken();
    res.json({ token, deepLink });
  });

  app.get('/api/auth/telegram/status/:token', (req: Request, res: Response) => {
    const status = getVerificationStatus(req.params.token);
    res.json(status);
  });

  // Telegram calls this endpoint directly when someone messages the bot.
  // The secret_token header (set during setWebhook) proves the request
  // actually came from Telegram and not an attacker hitting this URL
  // directly to fake a verification.
  app.post('/api/telegram/webhook', async (req: Request, res: Response) => {
    if (TELEGRAM_WEBHOOK_SECRET) {
      const incomingSecret = req.header('X-Telegram-Bot-Api-Secret-Token');
      if (incomingSecret !== TELEGRAM_WEBHOOK_SECRET) {
        res.status(401).end();
        return;
      }
    }
    const message = req.body?.message;
    const text: string | undefined = message?.text;
    const from = message?.from;

    if (text && text.startsWith('/start') && from) {
      const parts = text.split(' ');
      const token = parts[1];
      if (token) {
        const ok = markVerified(token, from);
        await sendTelegramMessage(
          from.id,
          ok
            ? '✅ Verified! You can return to the browser now — your table is ready to order.'
            : '⚠️ This verification link has expired or was already used. Please request a new one from the website.'
        );
      } else {
        await sendTelegramMessage(from.id, 'Hi! Open this bot from the restaurant website to verify your account.');
      }
    }
    res.status(200).end(); // Telegram just needs a 200; content is ignored
  });

  // --- EXCHANGE RATES (for customer-facing currency display only) ---
  // The admin always works in so'm — these rates only power an optional
  // "show me this in USD/RUB" conversion for customers. Nothing about the
  // actual amount charged/recorded changes based on this.
  function readExchangeRates(): Record<string, { rateToSom: number; updatedAt: string; source: string }> {
    const rows = db.prepare('SELECT currency, rate_to_som, updated_at, source FROM exchange_rates').all() as {
      currency: string;
      rate_to_som: number;
      updated_at: string;
      source: string;
    }[];
    const result: Record<string, { rateToSom: number; updatedAt: string; source: string }> = {};
    for (const row of rows) {
      result[row.currency] = { rateToSom: row.rate_to_som, updatedAt: row.updated_at, source: row.source };
    }
    return result;
  }

  // --- RESTAURANT SETTINGS (tax % and service fee %, admin-editable) ---
  function readSettings(): { taxPercent: number; serviceFeePercent: number } {
    const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    return {
      taxPercent: Number(map.taxPercent ?? 8),
      serviceFeePercent: Number(map.serviceFeePercent ?? 5)
    };
  }

  app.get('/api/settings', (_req: Request, res: Response) => {
    res.json(readSettings());
  });

  app.post(
    '/api/admin/settings',
    requireRole('admin'),
    validateBody(settingsUpdateSchema),
    (req: Request, res: Response) => {
      const { taxPercent, serviceFeePercent } = req.body;
      if (taxPercent !== undefined) {
        db.prepare(`INSERT INTO settings (key, value) VALUES ('taxPercent', ?) ON CONFLICT(key) DO UPDATE SET value = ?`).run(
          String(taxPercent),
          String(taxPercent)
        );
      }
      if (serviceFeePercent !== undefined) {
        db.prepare(
          `INSERT INTO settings (key, value) VALUES ('serviceFeePercent', ?) ON CONFLICT(key) DO UPDATE SET value = ?`
        ).run(String(serviceFeePercent), String(serviceFeePercent));
      }
      const updated = readSettings();
      broadcastTableAll('SETTINGS_UPDATED', updated);
      broadcastStaff('SETTINGS_UPDATED', updated);
      res.json({ success: true, ...updated });
    }
  );

  app.get('/api/exchange-rates', (_req: Request, res: Response) => {
    res.json(readExchangeRates());
  });

  app.post(
    '/api/admin/exchange-rates',
    requireRole('admin'),
    validateBody(exchangeRateUpdateSchema),
    (req: Request, res: Response) => {
      const { currency, rateToSom } = req.body;
      db.prepare(
        `INSERT INTO exchange_rates (currency, rate_to_som, updated_at, source) VALUES (?, ?, ?, 'manual')
         ON CONFLICT(currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'manual'`
      ).run(currency, rateToSom, new Date().toISOString(), rateToSom, new Date().toISOString());
      broadcastTableAll('EXCHANGE_RATES_UPDATED', readExchangeRates());
      res.json({ success: true, rates: readExchangeRates() });
    }
  );

  // Best-effort daily auto-refresh from a free public rate API. If this
  // fails for any reason (no internet egress, API down, etc.) the existing
  // rates just stay as they are — this never blocks or breaks anything.
  async function refreshExchangeRatesFromLiveSource() {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      const res = await fetch('https://open.er-api.com/v6/latest/USD', { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) return;
      const data: any = await res.json();
      const usdToUzs = data?.rates?.UZS;
      const usdToRub = data?.rates?.RUB;
      if (typeof usdToUzs !== 'number' || usdToUzs <= 0) return;

      const now = new Date().toISOString();
      db.prepare(
        `INSERT INTO exchange_rates (currency, rate_to_som, updated_at, source) VALUES ('USD', ?, ?, 'auto')
         ON CONFLICT(currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'auto'`
      ).run(usdToUzs, now, usdToUzs, now);

      if (typeof usdToRub === 'number' && usdToRub > 0) {
        const rubToUzs = usdToUzs / usdToRub;
        db.prepare(
          `INSERT INTO exchange_rates (currency, rate_to_som, updated_at, source) VALUES ('RUB', ?, ?, 'auto')
           ON CONFLICT(currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'auto'`
        ).run(rubToUzs, now, rubToUzs, now);
      }
      logger.info({ usdToUzs, usdToRub }, 'exchange rates auto-refreshed');
      broadcastTableAll('EXCHANGE_RATES_UPDATED', readExchangeRates());
    } catch (err) {
      logger.warn({ err }, 'exchange rate auto-refresh failed — keeping existing rates');
    }
  }

  app.get('/api/health', (_req: Request, res: Response) => {
    try {
      db.prepare('SELECT 1').get();
      res.json({ status: 'ok', timestamp: new Date().toISOString() });
    } catch {
      res.status(503).json({ status: 'error', error: 'database unavailable' });
    }
  });

  // --- AUTH ENDPOINTS (real, server-side, hashed) ---
  app.post('/api/auth/admin/login', loginLimiter, validateBody(loginSchema), (req: Request, res: Response) => {
    const lockout = isLockedOut('admin');
    if (lockout.locked) {
      res.status(429).json({ error: 'Account temporarily locked due to failed attempts.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    const { password } = req.body;
    if (!verifyPassword('admin', password)) {
      recordFailedAttempt('admin');
      res.status(401).json({ error: 'Invalid password' });
      return;
    }
    clearFailedAttempts('admin');
    setSessionCookie(res, 'admin');
    res.json({ success: true });
  });

  app.post('/api/auth/kitchen/login', loginLimiter, validateBody(loginSchema), (req: Request, res: Response) => {
    const lockout = isLockedOut('kitchen');
    if (lockout.locked) {
      res.status(429).json({ error: 'Account temporarily locked due to failed attempts.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    const { password } = req.body;
    if (!verifyPassword('kitchen', password) && !verifyPassword('admin', password)) {
      recordFailedAttempt('kitchen');
      res.status(401).json({ error: 'Invalid PIN' });
      return;
    }
    clearFailedAttempts('kitchen');
    setSessionCookie(res, 'kitchen');
    res.json({ success: true });
  });

  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    clearSessionCookie(res);
    res.json({ success: true });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const token = req.cookies?.session;
    if (!token) {
      res.json({ role: null });
      return;
    }
    const payload = verifySession(token);
    res.json({ role: payload?.role || null });
  });

  // Changing the password requires an active, valid admin session cookie
  // (requireRole('admin')) — that's the identity proof, since this app uses
  // a single shared admin account rather than per-user logins.
  app.post(
    '/api/auth/admin/change-password',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword('admin', req.body.newPassword);
      res.json({ success: true });
    }
  );

  app.post(
    '/api/auth/kitchen/change-pin',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword('kitchen', req.body.newPassword);
      res.json({ success: true });
    }
  );

  // --- MENU ENDPOINTS (reads public, writes admin-only) ---
  app.get('/api/menu', (_req: Request, res: Response) => {
    res.json(readMenu());
  });

  app.post('/api/menu', requireRole('admin'), validateBody(menuItemCreateSchema), (req: Request, res: Response) => {
    const body = req.body;
    const newItem: MenuItem = {
      id: 'm-' + Date.now(),
      name: body.nameUz, // canonical field — kitchen/orders/receipts always show Uzbek
      description: body.descriptionUz,
      nameUz: body.nameUz,
      nameRu: body.nameRu,
      nameEn: body.nameEn,
      descriptionUz: body.descriptionUz,
      descriptionRu: body.descriptionRu,
      descriptionEn: body.descriptionEn,
      price: body.price,
      category: body.category,
      image: body.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
      stock: body.stock,
      isAvailable: body.stock > 0,
      dietary: body.dietary,
      prepTimeMinutes: body.prepTimeMinutes,
      customizations: body.customizations
    };
    db.prepare('INSERT INTO menu_items (id, data) VALUES (?, ?)').run(newItem.id, JSON.stringify(newItem));
    req.log.info({ menuItemId: newItem.id }, 'menu item created');
    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.status(201).json(newItem);
  });

  app.put('/api/menu/:id', requireRole('admin'), validateBody(menuItemUpdateSchema), (req: Request, res: Response) => {
    const { id } = req.params;
    const row = db.prepare('SELECT data FROM menu_items WHERE id = ?').get(id) as { data: string } | undefined;
    if (!row) {
      res.status(404).json({ error: 'Item not found' });
      return;
    }
    const existing: MenuItem = JSON.parse(row.data);
    const previousStock = existing.stock;
    const patch = { ...req.body };
    if (patch.image === '') delete patch.image; // empty string means "no change", not "clear the photo"
    const updated: MenuItem = { ...existing, ...patch, id: existing.id };
    // Keep the canonical name/description (used by kitchen/orders/receipts)
    // in sync whenever the Uzbek fields are edited.
    if (patch.nameUz !== undefined) updated.name = patch.nameUz;
    if (patch.descriptionUz !== undefined) updated.description = patch.descriptionUz;
    if (updated.stock <= 0) updated.isAvailable = false;

    db.prepare('UPDATE menu_items SET data = ? WHERE id = ?').run(JSON.stringify(updated), id);

    if (req.body.stock !== undefined && req.body.stock !== previousStock) {
      const change = req.body.stock - previousStock;
      const log: InventoryLog = {
        id: 'log-' + Date.now(),
        menuItemId: id,
        menuItemName: updated.name,
        changeAmount: change,
        newStock: updated.stock,
        reason: req.body.stockReason || (change > 0 ? 'restock' : 'manual_adjustment'),
        timestamp: new Date().toISOString()
      };
      db.prepare('INSERT INTO inventory_logs (id, data, created_at) VALUES (?, ?, ?)').run(
        log.id,
        JSON.stringify(log),
        log.timestamp
      );
    }

    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.json(updated);
  });

  app.delete('/api/menu/:id', requireRole('admin'), (req: Request, res: Response) => {
    const { id } = req.params;
    db.prepare('DELETE FROM menu_items WHERE id = ?').run(id);
    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.json({ success: true, id });
  });

  // --- ORDERS ENDPOINTS ---
  app.get('/api/orders', requireRole('admin', 'kitchen'), (_req: Request, res: Response) => {
    res.json(readOrders());
  });

  // Customers can only fetch orders for their own table, not the whole list.
  app.get('/api/orders/table/:tableNumber', (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).json({ error: 'Invalid table number' });
      return;
    }
    res.json(readOrders().filter(o => o.tableNumber === tableNumber));
  });

  app.post('/api/orders', orderLimiter, validateBody(orderCreateSchema), (req: Request, res: Response) => {
    const idempotencyKey = req.header('Idempotency-Key');

    if (idempotencyKey) {
      const existing = db.prepare('SELECT order_id FROM idempotency_keys WHERE key = ?').get(idempotencyKey) as
        | { order_id: string }
        | undefined;
      if (existing) {
        const row = db.prepare('SELECT data FROM orders WHERE id = ?').get(existing.order_id) as
          | { data: string }
          | undefined;
        if (row) {
          res.status(200).json(JSON.parse(row.data));
          return;
        }
      }
    }

    const {
      tableNumber,
      customerName,
      customerPhoneOrEmail,
      items,
      subtotal,
      discount,
      loyaltyPointsRedeemed,
      paymentMethod,
      orderNote
    } = req.body;

    // Server-side recompute/sanity-check against authoritative menu prices,
    // instead of trusting client-submitted totals outright.
    const menu = readMenu();
    let recomputedSubtotal = 0;
    for (const cartItem of items) {
      const menuItem = menu.find(m => m.id === cartItem.menuItem.id);
      if (!menuItem) {
        res.status(400).json({ error: `Menu item ${cartItem.menuItem.id} does not exist` });
        return;
      }
      if (!menuItem.isAvailable || menuItem.stock < cartItem.quantity) {
        res.status(409).json({ error: `${menuItem.name} is not available in the requested quantity` });
        return;
      }
      recomputedSubtotal += cartItem.itemTotal;
    }
    if (Math.abs(recomputedSubtotal - subtotal) > 0.5) {
      res.status(400).json({ error: 'Order total does not match menu pricing' });
      return;
    }

    // Tax and service charge are ALWAYS computed here from the current
    // settings, never trusted from the client — otherwise a customer could
    // tamper with these values in the request to pay less. The discount
    // (from loyalty points) is also capped server-side at 50% of subtotal,
    // matching the same rule the cart UI uses.
    const { taxPercent, serviceFeePercent } = readSettings();
    const authoritativeTax = Math.round((recomputedSubtotal * taxPercent) / 100);
    const authoritativeServiceCharge = Math.round((recomputedSubtotal * serviceFeePercent) / 100);
    const requestedDiscount = Math.max(0, Number(discount) || 0);
    const maxDiscount = recomputedSubtotal * 0.5;
    const authoritativeDiscount = Math.min(requestedDiscount, maxDiscount);
    const authoritativeTotal = Math.max(
      0,
      recomputedSubtotal + authoritativeTax + authoritativeServiceCharge - authoritativeDiscount
    );

    const orderId = 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random() * 900);
    // Loyalty economics, calibrated for so'm-scale totals: earn 1 point per
    // 1,000 so'm spent, each point worth 100 so'm when redeemed (~10% back).
    const pointsEarned = Math.round(authoritativeTotal / 1000);

    const newOrder: Order = {
      id: orderId,
      tableNumber: Number(tableNumber),
      customerName: customerName || `Table ${tableNumber} Guest`,
      customerPhoneOrEmail: customerPhoneOrEmail || '',
      items,
      subtotal: recomputedSubtotal,
      tax: authoritativeTax,
      serviceCharge: authoritativeServiceCharge,
      discount: authoritativeDiscount,
      totalAmount: authoritativeTotal,
      status: 'pending',
      paymentStatus: paymentMethod === 'card' ? 'paid' : 'unpaid',
      paymentMethod: paymentMethod || 'pay_at_counter',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedMinutes: 15,
      loyaltyPointsEarned: pointsEarned,
      loyaltyPointsRedeemed: Number(loyaltyPointsRedeemed) || 0,
      orderNote
    };

    const tx = db.transaction(() => {
      db.prepare('INSERT INTO orders (id, table_number, data, created_at) VALUES (?, ?, ?, ?)').run(
        newOrder.id,
        newOrder.tableNumber,
        JSON.stringify(newOrder),
        newOrder.createdAt
      );

      if (idempotencyKey) {
        db.prepare('INSERT INTO idempotency_keys (key, order_id, created_at) VALUES (?, ?, ?)').run(
          idempotencyKey,
          newOrder.id,
          new Date().toISOString()
        );
      }

      for (const cartItem of items) {
        const row = db.prepare('SELECT data FROM menu_items WHERE id = ?').get(cartItem.menuItem.id) as
          | { data: string }
          | undefined;
        if (!row) continue;
        const menuItem: MenuItem = JSON.parse(row.data);
        const newStock = Math.max(0, menuItem.stock - cartItem.quantity);
        menuItem.stock = newStock;
        if (newStock === 0) menuItem.isAvailable = false;
        db.prepare('UPDATE menu_items SET data = ? WHERE id = ?').run(JSON.stringify(menuItem), menuItem.id);

        const log: InventoryLog = {
          id: 'log-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
          menuItemId: menuItem.id,
          menuItemName: menuItem.name,
          changeAmount: -cartItem.quantity,
          newStock,
          reason: 'customer_order',
          timestamp: new Date().toISOString()
        };
        db.prepare('INSERT INTO inventory_logs (id, data, created_at) VALUES (?, ?, ?)').run(
          log.id,
          JSON.stringify(log),
          log.timestamp
        );
      }

      const tableRow = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(Number(tableNumber)) as
        | { data: string }
        | undefined;
      if (tableRow) {
        const t: Table = JSON.parse(tableRow.data);
        t.status = 'eating';
        t.currentOrderId = orderId;
        t.activeItemsCount = items.length;
        db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), t.tableNumber);
      }

      if (customerPhoneOrEmail) {
        const loyaltyRow = db
          .prepare('SELECT id, data FROM loyalty_members WHERE phone_or_email = ?')
          .get(String(customerPhoneOrEmail).toLowerCase()) as { id: string; data: string } | undefined;
        if (loyaltyRow) {
          const member: LoyaltyMember = JSON.parse(loyaltyRow.data);
          member.pointsBalance += pointsEarned - (Number(loyaltyPointsRedeemed) || 0);
          member.totalSpent += authoritativeTotal;
          member.ordersCount += 1;
          if (member.totalSpent > 500) member.tier = 'Platinum';
          else if (member.totalSpent > 200) member.tier = 'Gold';
          db.prepare('UPDATE loyalty_members SET data = ? WHERE id = ?').run(JSON.stringify(member), member.id);
        }
      }
    });
    tx();

    req.log.info({ orderId, tableNumber }, 'order created');
    broadcastStaff('ORDER_CREATED', { order: newOrder });
    broadcastTable(Number(tableNumber), 'ORDER_CREATED', { order: newOrder });
    broadcastTableAll('MENU_UPDATED', readMenu());
    res.status(201).json(newOrder);
  });

  app.patch(
    '/api/orders/:id/status',
    requireRole('admin', 'kitchen'),
    validateBody(orderStatusUpdateSchema),
    (req: Request, res: Response) => {
      const { id } = req.params;
      const { status, paymentStatus } = req.body;

      const row = db.prepare('SELECT data FROM orders WHERE id = ?').get(id) as { data: string } | undefined;
      if (!row) {
        res.status(404).json({ error: 'Order not found' });
        return;
      }
      const order: Order = JSON.parse(row.data);
      if (status) order.status = status;
      if (paymentStatus) order.paymentStatus = paymentStatus;
      order.updatedAt = new Date().toISOString();

      db.prepare('UPDATE orders SET data = ? WHERE id = ?').run(JSON.stringify(order), id);

      if (status === 'paid') {
        const tableRow = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(order.tableNumber) as
          | { data: string }
          | undefined;
        if (tableRow) {
          const t: Table = JSON.parse(tableRow.data);
          t.status = 'available';
          t.currentOrderId = undefined;
          t.activeItemsCount = 0;
          db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), t.tableNumber);
          broadcastStaff('TABLES_UPDATED', readTables());
        }
      }

      broadcastStaff('ORDER_UPDATED', { order });
      broadcastTable(order.tableNumber, 'ORDER_UPDATED', { order });
      res.json(order);
    }
  );

  // --- LOYALTY ENDPOINTS ---
  app.get('/api/loyalty', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    const query = String(req.query.q || '').toLowerCase().trim();
    if (!query) {
      res.json(readLoyalty());
      return;
    }
    const member = readLoyalty().find(l => l.phoneOrEmail.toLowerCase() === query || l.name.toLowerCase().includes(query));
    res.json(member || null);
  });

  // Public, narrow: a customer can look up ONLY their own record by exact
  // phone/email match — never a general search, never the full list.
  app.get('/api/loyalty/lookup', orderLimiter, (req: Request, res: Response) => {
    const identifier = String(req.query.identifier || '').toLowerCase().trim();
    if (!identifier) {
      res.status(400).json({ error: 'identifier is required' });
      return;
    }
    const row = db.prepare('SELECT data FROM loyalty_members WHERE phone_or_email = ?').get(identifier) as
      | { data: string }
      | undefined;
    res.json(row ? JSON.parse(row.data) : null);
  });

  app.post('/api/loyalty', orderLimiter, validateBody(loyaltyRegisterSchema), (req: Request, res: Response) => {
    const { name, phoneOrEmail, confirmationCode } = req.body;
    const key = String(phoneOrEmail).toLowerCase();
    const existingRow = db.prepare('SELECT data FROM loyalty_members WHERE phone_or_email = ?').get(key) as
      | { data: string }
      | undefined;
    if (existingRow) {
      res.json(JSON.parse(existingRow.data));
      return;
    }
    const newMember: LoyaltyMember = {
      id: 'loy-' + Date.now(),
      name,
      phoneOrEmail,
      confirmationCode: confirmationCode || Math.floor(1000 + Math.random() * 9000).toString(),
      pointsBalance: 100,
      tier: 'Silver',
      totalSpent: 0,
      ordersCount: 0,
      joinedDate: new Date().toISOString().split('T')[0]
    };
    db.prepare('INSERT INTO loyalty_members (id, phone_or_email, data) VALUES (?, ?, ?)').run(
      newMember.id,
      key,
      JSON.stringify(newMember)
    );
    res.status(201).json(newMember);
  });

  // --- TABLES ENDPOINTS ---
  app.get('/api/tables', (_req: Request, res: Response) => {
    res.json(readTables());
  });

  app.post('/api/tables', requireRole('admin'), validateBody(tableCreateSchema), (req: Request, res: Response) => {
    const { tableNumber, capacity, comment } = req.body;
    const existing = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(tableNumber) as
      | { data: string }
      | undefined;
    if (existing) {
      const t: Table = JSON.parse(existing.data);
      t.capacity = capacity;
      t.comment = comment ?? t.comment ?? '';
      db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), tableNumber);
      broadcastStaff('TABLES_UPDATED', readTables());
      broadcastTableAll('TABLE_INFO_UPDATED', { tableNumber, comment: t.comment });
      res.json(t);
      return;
    }
    const newTable: Table = { tableNumber, capacity, status: 'available', activeItemsCount: 0, comment: comment || '' };
    db.prepare('INSERT INTO tables (table_number, data) VALUES (?, ?)').run(tableNumber, JSON.stringify(newTable));
    broadcastStaff('TABLES_UPDATED', readTables());
    res.status(201).json(newTable);
  });

  app.delete('/api/tables/:tableNumber', requireRole('admin'), (req: Request, res: Response) => {
    const tableNum = Number(req.params.tableNumber);
    db.prepare('DELETE FROM tables WHERE table_number = ?').run(tableNum);
    broadcastStaff('TABLES_UPDATED', readTables());
    res.json({ success: true, tableNumber: tableNum });
  });

  app.get('/api/inventory-logs', requireRole('admin'), (_req: Request, res: Response) => {
    res.json(readInventoryLogs());
  });

  app.delete('/api/orders/:id', requireRole('admin'), (req: Request, res: Response) => {
    const { id } = req.params;
    const result = db.prepare('DELETE FROM orders WHERE id = ?').run(id);
    if (result.changes === 0) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    req.log.info({ orderId: id }, 'order deleted by admin');
    broadcastStaff('ORDER_DELETED', { id });
    res.json({ success: true, id });
  });

  // Data retention: deletes orders (and related stale rows) older than N
  // days. Runs automatically once a day (see runRetentionCleanup below) and
  // can also be triggered on demand from the admin dashboard.
  function runRetentionCleanup(olderThanDays: number) {
    const cutoff = new Date(Date.now() - olderThanDays * 24 * 60 * 60 * 1000).toISOString();
    const ordersDeleted = db.prepare('DELETE FROM orders WHERE created_at < ?').run(cutoff).changes;
    const logsDeleted = db.prepare('DELETE FROM inventory_logs WHERE created_at < ?').run(cutoff).changes;
    const idempotencyDeleted = db.prepare('DELETE FROM idempotency_keys WHERE created_at < ?').run(cutoff).changes;
    const telegramDeleted = db
      .prepare(`DELETE FROM telegram_verifications WHERE created_at < ?`)
      .run(cutoff).changes;
    return { ordersDeleted, logsDeleted, idempotencyDeleted, telegramDeleted, cutoff };
  }

  app.post('/api/admin/orders/cleanup', requireRole('admin'), (req: Request, res: Response) => {
    const days = Number(req.body?.olderThanDays) || 30;
    if (days < 1 || days > 3650) {
      res.status(400).json({ error: 'olderThanDays must be between 1 and 3650' });
      return;
    }
    const result = runRetentionCleanup(days);
    req.log.info(result, 'manual retention cleanup run');
    broadcastStaff('ORDERS_CLEANED_UP', result);
    res.json({ success: true, ...result });
  });

  app.post('/api/admin/backup', requireRole('admin'), (_req: Request, res: Response) => {
    const backupPath = backupNow();
    res.json({ success: true, path: backupPath });
  });

  // --- Static assets / SPA serving ---
  if (isProd) {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(
      express.static(distPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-cache');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        }
      })
    );
    app.get('*all', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  }

  // --- Centralized error handler: never leak stack traces to the client ---
  app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
    req.log?.error({ err }, 'unhandled error');
    if (res.headersSent) return;
    res.status(500).json({ error: 'Internal server error' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Restaurant QR System listening on http://localhost:${PORT} (env=${process.env.NODE_ENV || 'development'})`);
  });

  // Automatic data retention: keeps the last N days of orders by default
  // (30, configurable via ORDER_RETENTION_DAYS) so the database doesn't
  // grow forever with tickets nobody needs anymore. Admin can also trigger
  // this manually or change the window from the dashboard.
  const retentionDays = Number(process.env.ORDER_RETENTION_DAYS) || 30;
  const runInitialCleanup = () => {
    try {
      const result = runRetentionCleanup(retentionDays);
      if (result.ordersDeleted > 0) {
        logger.info(result, 'automatic retention cleanup ran');
      }
    } catch (err) {
      logger.error({ err }, 'automatic retention cleanup failed');
    }
  };
  runInitialCleanup();
  setInterval(runInitialCleanup, 24 * 60 * 60 * 1000);

  refreshExchangeRatesFromLiveSource();
  setInterval(refreshExchangeRatesFromLiveSource, 24 * 60 * 60 * 1000);

  if (telegramConfigured && process.env.APP_URL) {
    registerWebhook(process.env.APP_URL, TELEGRAM_WEBHOOK_SECRET);
    logger.info('Telegram webhook registration attempted');
  } else if (telegramConfigured) {
    logger.warn('TELEGRAM_BOT_TOKEN is set but APP_URL is missing — webhook was not registered');
  }
}

startServer().catch(err => {
  logger.error(err, 'Fatal startup error');
  process.exit(1);
});

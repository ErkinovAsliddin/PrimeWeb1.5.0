import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { ZodSchema } from 'zod';
import { createServer as createViteServer } from 'vite';
import { db, backupNow } from './src/server/db';
import {
  requireRole,
  verifyPassword,
  setPassword,
  setSessionCookie,
  clearSessionCookie,
  verifySession,
  isLockedOut,
  recordFailedAttempt,
  clearFailedAttempts
} from './src/server/auth';
import {
  menuItemCreateSchema,
  menuItemUpdateSchema,
  orderCreateSchema,
  orderStatusUpdateSchema,
  tableCreateSchema,
  loyaltyRegisterSchema,
  loginSchema,
  changePasswordSchema
} from './src/server/validation';
import { MenuItem, Order, Table, LoyaltyMember, InventoryLog } from './src/types';

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------------
// Real-time updates via Server-Sent Events, split into two scopes:
//  - Staff stream (admin/kitchen only, session-gated): full order details,
//    inventory, and table state, exactly like a kitchen display needs.
//  - Table-scoped stream (public but narrow): a customer only receives
//    updates for their OWN table's order status and general menu/table
//    availability — never other tables' orders or any loyalty-member data.
// The original build broadcast full orders + the entire loyalty member list
// (names/phones/emails/points) to every connected browser tab, including
// customers. That data exposure is fixed by this split.
// ---------------------------------------------------------------------------
type SSEClient = { res: Response; tableNumber?: number };
const staffClients: Response[] = [];
const tableClients: SSEClient[] = [];

function sseSend(res: Response, type: string, data: unknown) {
  res.write(`data: ${JSON.stringify({ type, data, timestamp: new Date().toISOString() })}\n\n`);
}

function broadcastStaff(type: string, data: unknown) {
  staffClients.forEach(res => {
    try {
      sseSend(res, type, data);
    } catch (e) {
      logger.error({ err: e }, 'SSE staff send error');
    }
  });
}

function broadcastTable(tableNumber: number, type: string, data: unknown) {
  tableClients
    .filter(c => c.tableNumber === tableNumber)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE table send error');
      }
    });
}

function broadcastTableAll(type: string, data: unknown) {
  tableClients.forEach(c => {
    try {
      sseSend(c.res, type, data);
    } catch (e) {
      logger.error({ err: e }, 'SSE table-all send error');
    }
  });
}

// ---------------------------------------------------------------------------
// Generic request-validation middleware. Every mutating endpoint below runs
// its body through a zod schema before touching the database. Anything that
// doesn't match the schema is rejected with 400 and never reaches business
// logic.
// ---------------------------------------------------------------------------
function validateBody<T extends ZodSchema>(schema: T) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ error: 'Invalid request data', details: result.error.flatten() });
      return;
    }
    req.body = result.data;
    next();
  };
}

// --- Data access helpers (SQLite-backed, replacing the old in-memory arrays) --
function readMenu(): MenuItem[] {
  return (db.prepare('SELECT data FROM menu_items').all() as { data: string }[]).map(r => JSON.parse(r.data));
}
function readOrders(): Order[] {
  return (db.prepare('SELECT data FROM orders ORDER BY created_at DESC').all() as { data: string }[]).map(r =>
    JSON.parse(r.data)
  );
}
function readTables(): Table[] {
  return (db.prepare('SELECT data FROM tables ORDER BY table_number ASC').all() as { data: string }[]).map(r =>
    JSON.parse(r.data)
  );
}
function readLoyalty(): LoyaltyMember[] {
  return (db.prepare('SELECT data FROM loyalty_members').all() as { data: string }[]).map(r => JSON.parse(r.data));
}
function readInventoryLogs(): InventoryLog[] {
  return (db.prepare('SELECT data FROM inventory_logs ORDER BY created_at DESC LIMIT 500').all() as {
    data: string;
  }[]).map(r => JSON.parse(r.data));
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Trust the first proxy hop (needed on Hostinger/AWS behind Nginx/ALB/Cloudflare)
  // so rate limiting and secure cookies see the real client IP/protocol.
  app.set('trust proxy', 1);

  // --- Security headers ---
  app.use(
    helmet({
      contentSecurityPolicy: isProd
        ? {
            directives: {
              defaultSrc: ["'self'"],
              imgSrc: ["'self'", 'data:', 'https:'],
              scriptSrc: ["'self'"],
              styleSrc: ["'self'", "'unsafe-inline'"],
              connectSrc: ["'self'"],
              frameAncestors: ["'none'"]
            }
          }
        : false // relaxed in dev so Vite HMR keeps working
    })
  );

  // --- CORS: only allow explicitly configured origins (never "*") ---
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(o => o.trim()).filter(Boolean);
  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          callback(new Error('Not allowed by CORS'));
        }
      },
      credentials: true
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: '2mb' })); // was 50mb — no legitimate request here needs that
  app.use(express.urlencoded({ limit: '2mb', extended: true }));
  app.use(pinoHttp({ logger, redact: ['req.headers.cookie', 'req.headers.authorization'] }));

  // --- Rate limiting ---
  app.use(
    '/api/',
    rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false })
  );
  const loginLimiter = rateLimit({
    windowMs: 60_000,
    limit: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many login attempts. Please wait a minute and try again.' }
  });
  const orderLimiter = rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false });

  // Staff real-time stream: full detail, admin/kitchen session required.
  app.get('/api/events', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    staffClients.push(res);
    req.on('close', () => {
      const idx = staffClients.indexOf(res);
      if (idx !== -1) staffClients.splice(idx, 1);
    });
  });

  // Customer real-time stream: scoped to one table, no auth required (a
  // dining guest isn't logged in), but never carries other tables' data.
  app.get('/api/events/table/:tableNumber', (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).end();
      return;
    }
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    const client: SSEClient = { res, tableNumber };
    tableClients.push(client);
    req.on('close', () => {
      const idx = tableClients.indexOf(client);
      if (idx !== -1) tableClients.splice(idx, 1);
    });
  });

  app.get('/api/health', (_req: Request, res: Response) => {
    try {
      db.prepare('SELECT 1').get();
      res.json({ status: 'ok', timestamp: new Date().toISOString() });
    } catch {
      res.status(503).json({ status: 'error', error: 'database unavailable' });
    }
  });

  // --- AUTH ENDPOINTS (real, server-side, hashed) ---
  app.post('/api/auth/admin/login', loginLimiter, validateBody(loginSchema), (req: Request, res: Response) => {
    const lockout = isLockedOut('admin');
    if (lockout.locked) {
      res.status(429).json({ error: 'Account temporarily locked due to failed attempts.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    const { password } = req.body;
    if (!verifyPassword('admin', password)) {
      recordFailedAttempt('admin');
      res.status(401).json({ error: 'Invalid password' });
      return;
    }
    clearFailedAttempts('admin');
    setSessionCookie(res, 'admin');
    res.json({ success: true });
  });

  app.post('/api/auth/kitchen/login', loginLimiter, validateBody(loginSchema), (req: Request, res: Response) => {
    const lockout = isLockedOut('kitchen');
    if (lockout.locked) {
      res.status(429).json({ error: 'Account temporarily locked due to failed attempts.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    const { password } = req.body;
    if (!verifyPassword('kitchen', password) && !verifyPassword('admin', password)) {
      recordFailedAttempt('kitchen');
      res.status(401).json({ error: 'Invalid PIN' });
      return;
    }
    clearFailedAttempts('kitchen');
    setSessionCookie(res, 'kitchen');
    res.json({ success: true });
  });

  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    clearSessionCookie(res);
    res.json({ success: true });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const token = req.cookies?.session;
    if (!token) {
      res.json({ role: null });
      return;
    }
    const payload = verifySession(token);
    res.json({ role: payload?.role || null });
  });

  // Changing the password requires an active, valid admin session cookie
  // (requireRole('admin')) — that's the identity proof, since this app uses
  // a single shared admin account rather than per-user logins.
  app.post(
    '/api/auth/admin/change-password',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword('admin', req.body.newPassword);
      res.json({ success: true });
    }
  );

  app.post(
    '/api/auth/kitchen/change-pin',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword('kitchen', req.body.newPassword);
      res.json({ success: true });
    }
  );

  // --- MENU ENDPOINTS (reads public, writes admin-only) ---
  app.get('/api/menu', (_req: Request, res: Response) => {
    res.json(readMenu());
  });

  app.post('/api/menu', requireRole('admin'), validateBody(menuItemCreateSchema), (req: Request, res: Response) => {
    const body = req.body;
    const newItem: MenuItem = {
      id: 'm-' + Date.now(),
      name: body.name,
      description: body.description,
      price: body.price,
      category: body.category,
      image: body.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
      stock: body.stock,
      isAvailable: body.stock > 0,
      dietary: body.dietary,
      prepTimeMinutes: body.prepTimeMinutes,
      customizations: body.customizations
    };
    db.prepare('INSERT INTO menu_items (id, data) VALUES (?, ?)').run(newItem.id, JSON.stringify(newItem));
    req.log.info({ menuItemId: newItem.id }, 'menu item created');
    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.status(201).json(newItem);
  });

  app.put('/api/menu/:id', requireRole('admin'), validateBody(menuItemUpdateSchema), (req: Request, res: Response) => {
    const { id } = req.params;
    const row = db.prepare('SELECT data FROM menu_items WHERE id = ?').get(id) as { data: string } | undefined;
    if (!row) {
      res.status(404).json({ error: 'Item not found' });
      return;
    }
    const existing: MenuItem = JSON.parse(row.data);
    const previousStock = existing.stock;
    const updated: MenuItem = { ...existing, ...req.body, id: existing.id };
    if (updated.stock <= 0) updated.isAvailable = false;

    db.prepare('UPDATE menu_items SET data = ? WHERE id = ?').run(JSON.stringify(updated), id);

    if (req.body.stock !== undefined && req.body.stock !== previousStock) {
      const change = req.body.stock - previousStock;
      const log: InventoryLog = {
        id: 'log-' + Date.now(),
        menuItemId: id,
        menuItemName: updated.name,
        changeAmount: change,
        newStock: updated.stock,
        reason: req.body.stockReason || (change > 0 ? 'restock' : 'manual_adjustment'),
        timestamp: new Date().toISOString()
      };
      db.prepare('INSERT INTO inventory_logs (id, data, created_at) VALUES (?, ?, ?)').run(
        log.id,
        JSON.stringify(log),
        log.timestamp
      );
    }

    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.json(updated);
  });

  app.delete('/api/menu/:id', requireRole('admin'), (req: Request, res: Response) => {
    const { id } = req.params;
    db.prepare('DELETE FROM menu_items WHERE id = ?').run(id);
    broadcastTableAll('MENU_UPDATED', readMenu());
    broadcastStaff('MENU_UPDATED', readMenu());
    res.json({ success: true, id });
  });

  // --- ORDERS ENDPOINTS ---
  app.get('/api/orders', requireRole('admin', 'kitchen'), (_req: Request, res: Response) => {
    res.json(readOrders());
  });

  // Customers can only fetch orders for their own table, not the whole list.
  app.get('/api/orders/table/:tableNumber', (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).json({ error: 'Invalid table number' });
      return;
    }
    res.json(readOrders().filter(o => o.tableNumber === tableNumber));
  });

  app.post('/api/orders', orderLimiter, validateBody(orderCreateSchema), (req: Request, res: Response) => {
    const idempotencyKey = req.header('Idempotency-Key');

    if (idempotencyKey) {
      const existing = db.prepare('SELECT order_id FROM idempotency_keys WHERE key = ?').get(idempotencyKey) as
        | { order_id: string }
        | undefined;
      if (existing) {
        const row = db.prepare('SELECT data FROM orders WHERE id = ?').get(existing.order_id) as
          | { data: string }
          | undefined;
        if (row) {
          res.status(200).json(JSON.parse(row.data));
          return;
        }
      }
    }

    const {
      tableNumber,
      customerName,
      customerPhoneOrEmail,
      items,
      subtotal,
      tax,
      serviceCharge,
      discount,
      totalAmount,
      loyaltyPointsRedeemed,
      paymentMethod,
      orderNote
    } = req.body;

    // Server-side recompute/sanity-check against authoritative menu prices,
    // instead of trusting client-submitted totals outright.
    const menu = readMenu();
    let recomputedSubtotal = 0;
    for (const cartItem of items) {
      const menuItem = menu.find(m => m.id === cartItem.menuItem.id);
      if (!menuItem) {
        res.status(400).json({ error: `Menu item ${cartItem.menuItem.id} does not exist` });
        return;
      }
      if (!menuItem.isAvailable || menuItem.stock < cartItem.quantity) {
        res.status(409).json({ error: `${menuItem.name} is not available in the requested quantity` });
        return;
      }
      recomputedSubtotal += cartItem.itemTotal;
    }
    if (Math.abs(recomputedSubtotal - subtotal) > 0.5) {
      res.status(400).json({ error: 'Order total does not match menu pricing' });
      return;
    }

    const orderId = 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random() * 900);
    const pointsEarned = Math.round(totalAmount * 10);

    const newOrder: Order = {
      id: orderId,
      tableNumber: Number(tableNumber),
      customerName: customerName || `Table ${tableNumber} Guest`,
      customerPhoneOrEmail: customerPhoneOrEmail || '',
      items,
      subtotal: Number(subtotal),
      tax: Number(tax),
      serviceCharge: Number(serviceCharge),
      discount: Number(discount) || 0,
      totalAmount: Number(totalAmount),
      status: 'pending',
      paymentStatus: paymentMethod === 'card' ? 'paid' : 'unpaid',
      paymentMethod: paymentMethod || 'pay_at_counter',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedMinutes: 15,
      loyaltyPointsEarned: pointsEarned,
      loyaltyPointsRedeemed: Number(loyaltyPointsRedeemed) || 0,
      orderNote
    };

    const tx = db.transaction(() => {
      db.prepare('INSERT INTO orders (id, table_number, data, created_at) VALUES (?, ?, ?, ?)').run(
        newOrder.id,
        newOrder.tableNumber,
        JSON.stringify(newOrder),
        newOrder.createdAt
      );

      if (idempotencyKey) {
        db.prepare('INSERT INTO idempotency_keys (key, order_id, created_at) VALUES (?, ?, ?)').run(
          idempotencyKey,
          newOrder.id,
          new Date().toISOString()
        );
      }

      for (const cartItem of items) {
        const row = db.prepare('SELECT data FROM menu_items WHERE id = ?').get(cartItem.menuItem.id) as
          | { data: string }
          | undefined;
        if (!row) continue;
        const menuItem: MenuItem = JSON.parse(row.data);
        const newStock = Math.max(0, menuItem.stock - cartItem.quantity);
        menuItem.stock = newStock;
        if (newStock === 0) menuItem.isAvailable = false;
        db.prepare('UPDATE menu_items SET data = ? WHERE id = ?').run(JSON.stringify(menuItem), menuItem.id);

        const log: InventoryLog = {
          id: 'log-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
          menuItemId: menuItem.id,
          menuItemName: menuItem.name,
          changeAmount: -cartItem.quantity,
          newStock,
          reason: 'customer_order',
          timestamp: new Date().toISOString()
        };
        db.prepare('INSERT INTO inventory_logs (id, data, created_at) VALUES (?, ?, ?)').run(
          log.id,
          JSON.stringify(log),
          log.timestamp
        );
      }

      const tableRow = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(Number(tableNumber)) as
        | { data: string }
        | undefined;
      if (tableRow) {
        const t: Table = JSON.parse(tableRow.data);
        t.status = 'eating';
        t.currentOrderId = orderId;
        t.activeItemsCount = items.length;
        db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), t.tableNumber);
      }

      if (customerPhoneOrEmail) {
        const loyaltyRow = db
          .prepare('SELECT id, data FROM loyalty_members WHERE phone_or_email = ?')
          .get(String(customerPhoneOrEmail).toLowerCase()) as { id: string; data: string } | undefined;
        if (loyaltyRow) {
          const member: LoyaltyMember = JSON.parse(loyaltyRow.data);
          member.pointsBalance += pointsEarned - (Number(loyaltyPointsRedeemed) || 0);
          member.totalSpent += Number(totalAmount);
          member.ordersCount += 1;
          if (member.totalSpent > 500) member.tier = 'Platinum';
          else if (member.totalSpent > 200) member.tier = 'Gold';
          db.prepare('UPDATE loyalty_members SET data = ? WHERE id = ?').run(JSON.stringify(member), member.id);
        }
      }
    });
    tx();

    req.log.info({ orderId, tableNumber }, 'order created');
    broadcastStaff('ORDER_CREATED', { order: newOrder });
    broadcastTable(Number(tableNumber), 'ORDER_CREATED', { order: newOrder });
    broadcastTableAll('MENU_UPDATED', readMenu());
    res.status(201).json(newOrder);
  });

  app.patch(
    '/api/orders/:id/status',
    requireRole('admin', 'kitchen'),
    validateBody(orderStatusUpdateSchema),
    (req: Request, res: Response) => {
      const { id } = req.params;
      const { status, paymentStatus } = req.body;

      const row = db.prepare('SELECT data FROM orders WHERE id = ?').get(id) as { data: string } | undefined;
      if (!row) {
        res.status(404).json({ error: 'Order not found' });
        return;
      }
      const order: Order = JSON.parse(row.data);
      if (status) order.status = status;
      if (paymentStatus) order.paymentStatus = paymentStatus;
      order.updatedAt = new Date().toISOString();

      db.prepare('UPDATE orders SET data = ? WHERE id = ?').run(JSON.stringify(order), id);

      if (status === 'paid') {
        const tableRow = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(order.tableNumber) as
          | { data: string }
          | undefined;
        if (tableRow) {
          const t: Table = JSON.parse(tableRow.data);
          t.status = 'available';
          t.currentOrderId = undefined;
          t.activeItemsCount = 0;
          db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), t.tableNumber);
          broadcastStaff('TABLES_UPDATED', readTables());
        }
      }

      broadcastStaff('ORDER_UPDATED', { order });
      broadcastTable(order.tableNumber, 'ORDER_UPDATED', { order });
      res.json(order);
    }
  );

  // --- LOYALTY ENDPOINTS ---
  app.get('/api/loyalty', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    const query = String(req.query.q || '').toLowerCase().trim();
    if (!query) {
      res.json(readLoyalty());
      return;
    }
    const member = readLoyalty().find(l => l.phoneOrEmail.toLowerCase() === query || l.name.toLowerCase().includes(query));
    res.json(member || null);
  });

  // Public, narrow: a customer can look up ONLY their own record by exact
  // phone/email match — never a general search, never the full list.
  app.get('/api/loyalty/lookup', orderLimiter, (req: Request, res: Response) => {
    const identifier = String(req.query.identifier || '').toLowerCase().trim();
    if (!identifier) {
      res.status(400).json({ error: 'identifier is required' });
      return;
    }
    const row = db.prepare('SELECT data FROM loyalty_members WHERE phone_or_email = ?').get(identifier) as
      | { data: string }
      | undefined;
    res.json(row ? JSON.parse(row.data) : null);
  });

  app.post('/api/loyalty', orderLimiter, validateBody(loyaltyRegisterSchema), (req: Request, res: Response) => {
    const { name, phoneOrEmail, confirmationCode } = req.body;
    const key = String(phoneOrEmail).toLowerCase();
    const existingRow = db.prepare('SELECT data FROM loyalty_members WHERE phone_or_email = ?').get(key) as
      | { data: string }
      | undefined;
    if (existingRow) {
      res.json(JSON.parse(existingRow.data));
      return;
    }
    const newMember: LoyaltyMember = {
      id: 'loy-' + Date.now(),
      name,
      phoneOrEmail,
      confirmationCode: confirmationCode || Math.floor(1000 + Math.random() * 9000).toString(),
      pointsBalance: 100,
      tier: 'Silver',
      totalSpent: 0,
      ordersCount: 0,
      joinedDate: new Date().toISOString().split('T')[0]
    };
    db.prepare('INSERT INTO loyalty_members (id, phone_or_email, data) VALUES (?, ?, ?)').run(
      newMember.id,
      key,
      JSON.stringify(newMember)
    );
    res.status(201).json(newMember);
  });

  // --- TABLES ENDPOINTS ---
  app.get('/api/tables', (_req: Request, res: Response) => {
    res.json(readTables());
  });

  app.post('/api/tables', requireRole('admin'), validateBody(tableCreateSchema), (req: Request, res: Response) => {
    const { tableNumber, capacity } = req.body;
    const existing = db.prepare('SELECT data FROM tables WHERE table_number = ?').get(tableNumber) as
      | { data: string }
      | undefined;
    if (existing) {
      const t: Table = JSON.parse(existing.data);
      t.capacity = capacity;
      db.prepare('UPDATE tables SET data = ? WHERE table_number = ?').run(JSON.stringify(t), tableNumber);
      res.json(t);
      return;
    }
    const newTable: Table = { tableNumber, capacity, status: 'available', activeItemsCount: 0 };
    db.prepare('INSERT INTO tables (table_number, data) VALUES (?, ?)').run(tableNumber, JSON.stringify(newTable));
    broadcastStaff('TABLES_UPDATED', readTables());
    res.status(201).json(newTable);
  });

  app.delete('/api/tables/:tableNumber', requireRole('admin'), (req: Request, res: Response) => {
    const tableNum = Number(req.params.tableNumber);
    db.prepare('DELETE FROM tables WHERE table_number = ?').run(tableNum);
    broadcastStaff('TABLES_UPDATED', readTables());
    res.json({ success: true, tableNumber: tableNum });
  });

  app.get('/api/inventory-logs', requireRole('admin'), (_req: Request, res: Response) => {
    res.json(readInventoryLogs());
  });

  app.post('/api/admin/backup', requireRole('admin'), (_req: Request, res: Response) => {
    const backupPath = backupNow();
    res.json({ success: true, path: backupPath });
  });

  // --- Static assets / SPA serving ---
  if (isProd) {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(
      express.static(distPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-cache');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        }
      })
    );
    app.get('*all', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  }

  // --- Centralized error handler: never leak stack traces to the client ---
  app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
    req.log?.error({ err }, 'unhandled error');
    if (res.headersSent) return;
    res.status(500).json({ error: 'Internal server error' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Restaurant QR System listening on http://localhost:${PORT} (env=${process.env.NODE_ENV || 'development'})`);
  });
}

startServer().catch(err => {
  logger.error(err, 'Fatal startup error');
  process.exit(1);
});
